"""Read-only Windows metadata for known GameLoop processes.

Only QUERY_LIMITED_INFORMATION handles are requested. The reported architecture
belongs to the Windows host process; it does not establish the Android guest
game's architecture. No game memory is opened or scanned.
"""

import ctypes
from dataclasses import dataclass, field
import os
from pathlib import Path
import shutil


_WP_DWORD = ctypes.c_uint32
_WP_LONG = ctypes.c_int32
_WP_WORD = ctypes.c_uint16
_WP_ULONG_PTR = ctypes.c_size_t
_WP_HANDLE = ctypes.c_void_p


class _WP_PROCESSENTRY32W(ctypes.Structure):
    # WCHAR is always UTF-16 on Windows; c_wchar is wider on some test hosts.
    _fields_ = [
        ("dwSize", _WP_DWORD), ("cntUsage", _WP_DWORD),
        ("th32ProcessID", _WP_DWORD), ("th32DefaultHeapID", _WP_ULONG_PTR),
        ("th32ModuleID", _WP_DWORD), ("cntThreads", _WP_DWORD),
        ("th32ParentProcessID", _WP_DWORD), ("pcPriClassBase", _WP_LONG),
        ("dwFlags", _WP_DWORD), ("szExeFile", _WP_WORD * 260),
    ]


class _WP_SYSTEM_INFO(ctypes.Structure):
    _fields_ = [
        ("wProcessorArchitecture", _WP_WORD), ("wReserved", _WP_WORD),
        ("dwPageSize", _WP_DWORD),
        ("lpMinimumApplicationAddress", ctypes.c_void_p),
        ("lpMaximumApplicationAddress", ctypes.c_void_p),
        ("dwActiveProcessorMask", _WP_ULONG_PTR),
        ("dwNumberOfProcessors", _WP_DWORD), ("dwProcessorType", _WP_DWORD),
        ("dwAllocationGranularity", _WP_DWORD),
        ("wProcessorLevel", _WP_WORD), ("wProcessorRevision", _WP_WORD),
    ]


class _WP_VS_FIXEDFILEINFO(ctypes.Structure):
    _fields_ = [(name, _WP_DWORD) for name in (
        "dwSignature", "dwStrucVersion", "dwFileVersionMS", "dwFileVersionLS",
        "dwProductVersionMS", "dwProductVersionLS", "dwFileFlagsMask",
        "dwFileFlags", "dwFileOS", "dwFileType", "dwFileSubtype",
        "dwFileDateMS", "dwFileDateLS",
    )]


GAMELOOP_PROCESS_NAMES = frozenset(name.casefold() for name in (
    "aow_exe.exe", "AndroidEmulator.exe", "AndroidEmulatorEn.exe",
    "AndroidEmulatorEx.exe", "AndroidEmulatorExEn.exe",
    "QMEmulatorService.exe", "AppMarket.exe", "TBoxSvc.exe",
))


@dataclass(frozen=True)
class ProcessInfo:
    pid: int
    name: str
    architecture: str = "unknown"
    version: str | None = None
    path: str | None = field(default=None, repr=False)

    def to_report(self):
        """Exclude installation paths, which may contain a Windows user name."""
        return {
            "pid": self.pid,
            "name": self.name,
            "host_process_architecture": self.architecture,
            "file_version": self.version,
        }


def _wp_decode_name(array):
    return bytes(array).decode("utf-16-le", errors="replace").split("\x00", 1)[0]


def _wp_machine_name(machine):
    return {0x014C: "x86", 0x8664: "x64", 0xAA64: "arm64", 0x01C4: "arm32"}.get(machine, "unknown")


def _wp_bind_kernel32():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [_WP_DWORD, _WP_DWORD]
    kernel.CreateToolhelp32Snapshot.restype = _WP_HANDLE
    kernel.Process32FirstW.argtypes = [_WP_HANDLE, ctypes.POINTER(_WP_PROCESSENTRY32W)]
    kernel.Process32FirstW.restype = ctypes.c_int
    kernel.Process32NextW.argtypes = [_WP_HANDLE, ctypes.POINTER(_WP_PROCESSENTRY32W)]
    kernel.Process32NextW.restype = ctypes.c_int
    kernel.OpenProcess.argtypes = [_WP_DWORD, ctypes.c_int, _WP_DWORD]
    kernel.OpenProcess.restype = _WP_HANDLE
    kernel.CloseHandle.argtypes = [_WP_HANDLE]
    kernel.CloseHandle.restype = ctypes.c_int
    kernel.QueryFullProcessImageNameW.argtypes = [
        _WP_HANDLE, _WP_DWORD, ctypes.POINTER(ctypes.c_wchar), ctypes.POINTER(_WP_DWORD),
    ]
    kernel.QueryFullProcessImageNameW.restype = ctypes.c_int
    if hasattr(kernel, "IsWow64Process2"):
        kernel.IsWow64Process2.argtypes = [
            _WP_HANDLE, ctypes.POINTER(_WP_WORD), ctypes.POINTER(_WP_WORD),
        ]
        kernel.IsWow64Process2.restype = ctypes.c_int
    kernel.IsWow64Process.argtypes = [_WP_HANDLE, ctypes.POINTER(ctypes.c_int)]
    kernel.IsWow64Process.restype = ctypes.c_int
    kernel.GetNativeSystemInfo.argtypes = [ctypes.POINTER(_WP_SYSTEM_INFO)]
    kernel.GetNativeSystemInfo.restype = None
    return kernel


def _wp_process_architecture(kernel, handle):
    if hasattr(kernel, "IsWow64Process2"):
        process_machine, native_machine = _WP_WORD(), _WP_WORD()
        if kernel.IsWow64Process2(handle, ctypes.byref(process_machine), ctypes.byref(native_machine)):
            return _wp_machine_name(process_machine.value or native_machine.value)
    wow64 = ctypes.c_int()
    if not kernel.IsWow64Process(handle, ctypes.byref(wow64)):
        return "unknown"
    if wow64.value:
        return "x86"
    native = _WP_SYSTEM_INFO()
    kernel.GetNativeSystemInfo(ctypes.byref(native))
    return {0: "x86", 9: "x64", 12: "arm64", 5: "arm32"}.get(native.wProcessorArchitecture, "unknown")


def _wp_file_version(path):
    """Read the executable's fixed file-version resource, when available."""
    if not path:
        return None
    version = ctypes.WinDLL("version", use_last_error=True)
    version.GetFileVersionInfoSizeW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(_WP_DWORD)]
    version.GetFileVersionInfoSizeW.restype = _WP_DWORD
    version.GetFileVersionInfoW.argtypes = [ctypes.c_wchar_p, _WP_DWORD, _WP_DWORD, ctypes.c_void_p]
    version.GetFileVersionInfoW.restype = ctypes.c_int
    version.VerQueryValueW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint)]
    version.VerQueryValueW.restype = ctypes.c_int
    ignored = _WP_DWORD()
    size = version.GetFileVersionInfoSizeW(path, ctypes.byref(ignored))
    if not size or size > 16 * 1024 * 1024:
        return None
    buffer = ctypes.create_string_buffer(size)
    if not version.GetFileVersionInfoW(path, 0, size, buffer):
        return None
    pointer, length = ctypes.c_void_p(), ctypes.c_uint()
    if not version.VerQueryValueW(buffer, "\\", ctypes.byref(pointer), ctypes.byref(length)):
        return None
    if not pointer.value or length.value < ctypes.sizeof(_WP_VS_FIXEDFILEINFO):
        return None
    info = ctypes.cast(pointer, ctypes.POINTER(_WP_VS_FIXEDFILEINFO)).contents
    if info.dwSignature != 0xFEEF04BD:
        return None
    return ".".join(str(part) for part in (
        info.dwFileVersionMS >> 16, info.dwFileVersionMS & 0xFFFF,
        info.dwFileVersionLS >> 16, info.dwFileVersionLS & 0xFFFF,
    ))


def probe_gameloop_processes():
    """Return supported/processes/errors; processes are ProcessInfo instances.

    Access-denied processes remain listed, with unknown optional metadata. Only
    known GameLoop image names are queried. All messages omit full image paths.
    """
    if os.name != "nt":
        return {"supported": False, "processes": [], "errors": ["Windows süreç bilgisi bu platformda kullanılamıyor."]}
    processes, errors = [], []
    try:
        kernel = _wp_bind_kernel32()
    except (AttributeError, OSError) as exc:
        return {"supported": True, "processes": [], "errors": [f"Windows süreç API'si kullanılamadı ({type(exc).__name__})."]}
    snapshot = kernel.CreateToolhelp32Snapshot(0x00000002, 0)
    if snapshot in (None, ctypes.c_void_p(-1).value):
        return {"supported": True, "processes": [], "errors": [f"Süreç listesi alınamadı (Win32 {ctypes.get_last_error()})."]}
    try:
        entry = _WP_PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)
        success = kernel.Process32FirstW(snapshot, ctypes.byref(entry))
        while success:
            name = _wp_decode_name(entry.szExeFile)
            if name.casefold() in GAMELOOP_PROCESS_NAMES:
                pid = int(entry.th32ProcessID)
                path = None
                architecture = "unknown"
                file_version = None
                handle = kernel.OpenProcess(0x1000, False, pid)
                if handle:
                    try:
                        length = _WP_DWORD(32768)
                        image = ctypes.create_unicode_buffer(length.value)
                        if kernel.QueryFullProcessImageNameW(handle, 0, image, ctypes.byref(length)):
                            path = image.value
                        architecture = _wp_process_architecture(kernel, handle)
                    finally:
                        kernel.CloseHandle(handle)
                    try:
                        file_version = _wp_file_version(path)
                    except (OSError, AttributeError, ValueError):
                        pass
                else:
                    errors.append(f"PID {pid}: sınırlı süreç sorgusu reddedildi; mimari/sürüm bilinmiyor.")
                processes.append(ProcessInfo(pid, name, architecture, file_version, path))
            success = kernel.Process32NextW(snapshot, ctypes.byref(entry))
        error = ctypes.get_last_error()
        if error not in (0, 18):  # ERROR_NO_MORE_FILES is a normal end-of-snapshot.
            errors.append(f"Süreç listesi tamamlanamadı (Win32 {error}).")
    finally:
        kernel.CloseHandle(snapshot)
    processes.sort(key=lambda item: (item.name.casefold(), item.pid))
    return {"supported": True, "processes": processes, "errors": errors}


def find_adb_candidates(processes, explicit=None):
    """Find existing adb paths without recursive filesystem or network discovery."""
    requested = []
    if explicit is not None:
        requested.append(Path(explicit))
    relative = (
        "adb.exe", "adb", "ui/adb.exe", "AppMarket/adb.exe",
        "AndroidEmulator/adb.exe", "AndroidTbox/adb.exe", "aow_drv/adb.exe",
        "aow_drv/Android/adb.exe", "aow_drv/Android/DebugBridge/adb.exe",
    )
    for process in ([] if explicit is not None else list(processes)[:32]):
        if not process.path:
            continue
        # At most three installation ancestors and nine known relative names.
        for ancestor in list(Path(process.path).parents)[:3]:
            requested.extend(ancestor / suffix for suffix in relative)
    if explicit is None:
        located = shutil.which("adb.exe") or shutil.which("adb")
        if located:
            requested.append(Path(located))
    found, seen = [], set()
    for candidate in requested:
        try:
            if candidate.name.casefold() not in {"adb.exe", "adb"} or not candidate.is_file():
                continue
            resolved = candidate.resolve(strict=True)
            key = os.path.normcase(str(resolved))
            if key not in seen:
                found.append(str(resolved))
                seen.add(key)
        except (OSError, RuntimeError, ValueError):
            continue
    return found


"""Bounded read-only parsing for Android UE4 mappings and ELF identity.

This module does not open processes, run commands, request privileges, or execute
libraries. A caller supplies an already authorized file-range reader.
"""

from dataclasses import dataclass, field
import re


ENGINE_MAP_TEXT_LIMIT = 2 * 1024 * 1024
ENGINE_MAP_ROW_LIMIT = 128
ENGINE_MAX_READ = 64 * 1024
ENGINE_TOTAL_READ_LIMIT = 256 * 1024
ENGINE_MAX_OFFSET = 512 * 1024 * 1024
ENGINE_MAX_PHNUM = 256


class EngineProbeError(ValueError):
    """The input is unavailable, malformed, or outside bounded probe limits."""


@dataclass(frozen=True)
class MapRow:
    start: int
    end: int
    offset: int
    perms: str
    basename: str = "libUE4.so"
    deleted: bool = False
    path: str | None = field(default=None, repr=False)

    def to_report(self):
        return {"start": hex(self.start), "end": hex(self.end),
                "offset": hex(self.offset), "perms": self.perms,
                "basename": self.basename, "deleted": self.deleted}


def _safe_android_path(path):
    if not isinstance(path, str) or not 1 < len(path) <= 4096:
        return None
    if not re.fullmatch(r"/[A-Za-z0-9_./@+=~%\-]+", path):
        return None
    if any(part in ("", ".", "..") for part in path.split("/")[1:]):
        return None
    return path


def parse_ue4_maps(text):
    """Select bounded UE4 rows; full paths remain private and never serialize."""
    if not isinstance(text, str):
        raise EngineProbeError("Bellek eşleme yanıtı metin olmalı.")
    if len(text) > ENGINE_MAP_TEXT_LIMIT:
        raise EngineProbeError("Bellek eşleme yanıtı 2 MiB sınırını aşıyor.")
    try:
        byte_length = len(text.encode("utf-8"))
    except UnicodeError as exc:
        raise EngineProbeError("Bellek eşleme yanıtı geçerli Unicode içermeli.") from exc
    if byte_length > ENGINE_MAP_TEXT_LIMIT:
        raise EngineProbeError("Bellek eşleme yanıtı 2 MiB sınırını aşıyor.")
    rows = []
    for line in text.splitlines():
        parts = line.split(maxsplit=5)
        if len(parts) != 6:
            continue
        addresses, perms, file_offset, device, inode, path = parts
        deleted = path.endswith(" (deleted)")
        if deleted:
            path = path[:-10]
        if path.rsplit("/", 1)[-1] != "libUE4.so":
            continue
        if not re.fullmatch(r"[r-][w-][x-][ps]", perms):
            continue
        if not re.fullmatch(r"[0-9a-fA-F]+:[0-9a-fA-F]+", device) or not inode.isascii() or not inode.isdigit():
            continue
        match = re.fullmatch(r"([0-9a-fA-F]{1,16})-([0-9a-fA-F]{1,16})", addresses)
        if match is None or not re.fullmatch(r"[0-9a-fA-F]{1,16}", file_offset):
            continue
        start, end = (int(value, 16) for value in match.groups())
        if start >= end:
            continue
        rows.append(MapRow(start, end, int(file_offset, 16), perms,
                           deleted=deleted, path=_safe_android_path(path)))
        if len(rows) == ENGINE_MAP_ROW_LIMIT:
            break
    return rows


def engine_library_candidates(native_dir, mappings):
    """Return at most four safe paths, preferring non-deleted mapped files.

    These are candidates, not assertions that a remote path exists or can be
    read. The caller must perform its normal authorized read and handle denial.
    """
    candidates, seen = [], set()
    for index, mapping in enumerate(mappings):
        if index == ENGINE_MAP_ROW_LIMIT:
            break
        if not isinstance(mapping, MapRow) or mapping.deleted:
            continue
        path = _safe_android_path(mapping.path)
        if path and path.rsplit("/", 1)[-1] == "libUE4.so" and path not in seen:
            candidates.append((path, "mapped"))
            seen.add(path)
            if len(candidates) == 4:
                return candidates
    if isinstance(native_dir, str):
        directory = _safe_android_path(native_dir.rstrip("/"))
        path = directory + "/libUE4.so" if directory else None
        if path and path not in seen:
            candidates.append((path, "native_library_dir"))
    return candidates


class _BoundedReader:
    def __init__(self, callback):
        if not callable(callback):
            raise EngineProbeError("Dosya aralığı okuyucusu çağrılabilir olmalı.")
        self.callback = callback
        self.total = 0

    def read(self, offset, size):
        if type(offset) is not int or type(size) is not int or offset < 0 or size < 0:
            raise EngineProbeError("ELF okuma aralığı geçersiz.")
        if size > ENGINE_MAX_READ:
            raise EngineProbeError("Tek ELF okuması 64 KiB sınırını aşıyor.")
        if offset > ENGINE_MAX_OFFSET or offset + size > ENGINE_MAX_OFFSET:
            raise EngineProbeError("ELF dosya aralığı 512 MiB sınırını aşıyor.")
        if self.total + size > ENGINE_TOTAL_READ_LIMIT:
            raise EngineProbeError("Toplam ELF okuması 256 KiB sınırını aşıyor.")
        if not size:
            return b""
        self.total += size
        try:
            block = self.callback(offset, size)
        except Exception as exc:
            # Do not propagate commands, paths or unfiltered device responses.
            raise EngineProbeError("ELF dosya aralığı okunamadı.") from exc
        if not isinstance(block, (bytes, bytearray, memoryview)):
            raise EngineProbeError("ELF dosya aralığı eksik veya geçersiz.")
        block = bytes(block)
        if len(block) != size:
            raise EngineProbeError("ELF dosya aralığı eksik veya geçersiz.")
        return block


def _gnu_note_build_id(notes, endian):
    cursor = 0
    while cursor < len(notes):
        if len(notes) - cursor < 12:
            if any(notes[cursor:]):
                raise EngineProbeError("ELF not başlığı eksik.")
            return None
        name_size = int.from_bytes(notes[cursor:cursor + 4], endian)
        desc_size = int.from_bytes(notes[cursor + 4:cursor + 8], endian)
        note_type = int.from_bytes(notes[cursor + 8:cursor + 12], endian)
        name_start = cursor + 12
        name_end = name_start + name_size
        desc_start = name_start + ((name_size + 3) & ~3)
        desc_end = desc_start + desc_size
        if name_end > len(notes) or desc_end > len(notes):
            raise EngineProbeError("ELF not verisi eksik.")
        name = notes[name_start:name_end].rstrip(b"\0")
        if name == b"GNU" and note_type == 3:
            if not 1 <= desc_size <= 128:
                raise EngineProbeError("GNU Build ID uzunluğu geçersiz.")
            return notes[desc_start:desc_end].hex()
        cursor = desc_start + ((desc_size + 3) & ~3)
        if cursor > len(notes):
            raise EngineProbeError("ELF not hizalaması eksik.")
    return None


def metadata_from_reader(read_range):
    """Read ELF identity through exact bounded ranges, without loading the file.

    Supported ELF machines: ARM, AArch64, x86 and x86_64. An absent GNU Build ID
    is returned as None. Neither a machine nor a Build ID asserts game-version
    or offset compatibility. All reads are limited to 256 KiB total and 64 KiB
    per call, with a 512 MiB maximum file extent.
    """
    reader = _BoundedReader(read_range)
    identity = reader.read(0, 16)
    if identity[:4] != b"\x7fELF" or identity[4] not in (1, 2) or identity[5] not in (1, 2) or identity[6] != 1:
        raise EngineProbeError("Geçerli ve desteklenen bir ELF başlığı bulunamadı.")
    bits = 32 if identity[4] == 1 else 64
    endian = "little" if identity[5] == 1 else "big"
    header_size = 52 if bits == 32 else 64
    header = identity + reader.read(16, header_size - 16)
    machine_number = int.from_bytes(header[18:20], endian)
    machines = {40: (32, "ARM"), 183: (64, "AArch64"), 3: (32, "x86"), 62: (64, "x86_64")}
    machine = machines.get(machine_number)
    if machine is None or machine[0] != bits:
        raise EngineProbeError("ELF makine türü ile bit sınıfı desteklenmiyor veya uyuşmuyor.")
    if int.from_bytes(header[20:24], endian) != 1:
        raise EngineProbeError("ELF başlık sürümü geçersiz.")
    if bits == 32:
        phoff = int.from_bytes(header[28:32], endian)
        ehsize = int.from_bytes(header[40:42], endian)
        phsize = int.from_bytes(header[42:44], endian)
        phcount = int.from_bytes(header[44:46], endian)
        minimum_phsize = 32
    else:
        phoff = int.from_bytes(header[32:40], endian)
        ehsize = int.from_bytes(header[52:54], endian)
        phsize = int.from_bytes(header[54:56], endian)
        phcount = int.from_bytes(header[56:58], endian)
        minimum_phsize = 56
    if ehsize != header_size:
        raise EngineProbeError("ELF başlık boyutu geçersiz.")
    if phcount > ENGINE_MAX_PHNUM:
        raise EngineProbeError("ELF program başlığı sayısı 256 sınırını aşıyor.")
    if phcount and (not minimum_phsize <= phsize <= 256 or phoff < header_size):
        raise EngineProbeError("ELF program başlığı tablosu geçersiz.")
    table = reader.read(phoff, phsize * phcount) if phcount else b""
    build_id = None
    seen_notes = set()
    for index in range(phcount):
        entry = table[index * phsize:(index + 1) * phsize]
        if int.from_bytes(entry[:4], endian) != 4:  # PT_NOTE
            continue
        if bits == 32:
            offset = int.from_bytes(entry[4:8], endian)
            size = int.from_bytes(entry[16:20], endian)
        else:
            offset = int.from_bytes(entry[8:16], endian)
            size = int.from_bytes(entry[32:40], endian)
        if not size or (offset, size) in seen_notes:
            continue
        seen_notes.add((offset, size))
        if size > ENGINE_MAX_READ:
            raise EngineProbeError("ELF not bölümü 64 KiB sınırını aşıyor.")
        build_id = _gnu_note_build_id(reader.read(offset, size), endian)
        if build_id is not None:
            break
    return {"elf_bits": bits, "machine": machine[1], "gnu_build_id": build_id,
            "build_version_verified": False}


"""Bounded ADB transport diagnostics and explicit loopback reconnection.

No server restart, port scanning, privilege request, or configuration mutation is
performed. A caller supplies the installed ADB runner and asks for one port.
"""

import re
import subprocess


ADB_TRANSPORT_TEXT_LIMIT = 2 * 1024 * 1024
ADB_TRANSPORT_ROW_LIMIT = 128
_ADB_LOCAL_TCP = re.compile(r"(127\.0\.0\.1|localhost|\[::1\]):([0-9]{1,5})", re.IGNORECASE)
_ADB_LOCAL_EMULATOR = re.compile(r"emulator-([0-9]{1,5})")


def _adb_checked_text(text):
    if not isinstance(text, str):
        raise ValueError("ADB yanıtı metin olmalı.")
    if len(text) > ADB_TRANSPORT_TEXT_LIMIT or len(text.encode("utf-8", errors="replace")) > ADB_TRANSPORT_TEXT_LIMIT:
        raise ValueError("ADB yanıtı 2 MiB sınırını aşıyor.")
    return text


def _adb_local_endpoint(serial):
    match = _ADB_LOCAL_TCP.fullmatch(serial)
    if match:
        port = int(match.group(2))
        return (match.group(1).lower(), port) if 1 <= port <= 65535 else None
    match = _ADB_LOCAL_EMULATOR.fullmatch(serial)
    if match:
        port = int(match.group(1))
        return ("emulator", port) if 1 <= port <= 65535 else None
    return None


def local_adb_transports(text):
    """Return internal (serial, state) pairs for bounded, exact local transports.

    Unlike a device-only filter, offline and unauthorized rows are retained.
    Returned IDs are for command selection only; use the summary in reports.
    """
    text = _adb_checked_text(text)
    transports, seen = [], set()
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 2 or _adb_local_endpoint(parts[0]) is None:
            continue
        state = parts[1].lower()
        if not re.fullmatch(r"[a-z_-]{1,32}", state):
            state = "other"
        pair = (parts[0], state)
        if pair in seen:
            continue
        seen.add(pair)
        transports.append(pair)
        if len(transports) >= ADB_TRANSPORT_ROW_LIMIT:
            break
    return transports


def summarize_local_transports(transports):
    """Expose counts without serials, hostnames, paths, or raw command output."""
    summary = {"device": 0, "offline": 0, "unauthorized": 0, "other": 0}
    for _, state in list(transports)[:ADB_TRANSPORT_ROW_LIMIT]:
        summary[state if state in summary else "other"] += 1
    return summary


def parse_adb_version(text):
    """Extract version tokens only; discard Installed-as paths and host text."""
    text = _adb_checked_text(text).lstrip("\ufeff")
    protocol = re.search(r"(?im)^\s*Android Debug Bridge version ([0-9]{1,6}(?:\.[0-9]{1,6}){1,3})\s*$", text)
    package = re.search(r"(?im)^\s*Version ([0-9]{1,6}(?:\.[0-9]{1,6}){1,4}(?:-[A-Za-z0-9._+]{1,64})?)\s*$", text)
    return {"protocol_version": protocol.group(1) if protocol else None,
            "package_version": package.group(1) if package else None}


def _adb_valid_port(port):
    if type(port) is int:
        number = port
    elif isinstance(port, str) and re.fullmatch(r"[0-9]{1,5}", port):
        number = int(port)
    else:
        raise ValueError("Yerel ADB portu 1–65535 arasında bir tam sayı olmalı.")
    if not 1 <= number <= 65535:
        raise ValueError("Yerel ADB portu 1–65535 arasında bir tam sayı olmalı.")
    return number


def reconnect_local_adb(executable, port, runner):
    """Try one IPv4-loopback port, then verify its actual device-list state.

    `runner(executable, arguments, timeout=...)` must preserve the subprocess
    exit status. Connect-message text never establishes successful readiness.
    No transport IDs or raw subprocess errors are copied into the result.
    """
    result = {"attempted": False, "port": None, "status": "invalid_port",
              "message": "Yerel ADB portu 1–65535 arasında bir tam sayı olmalı."}
    try:
        port = _adb_valid_port(port)
    except ValueError:
        return result
    result["port"] = port
    if not executable or not callable(runner):
        result.update(status="command_error", message="Kurulu ADB dosyası veya komut çalıştırıcısı kullanılamıyor.")
        return result
    result["attempted"] = True
    try:
        runner(executable, ["connect", f"127.0.0.1:{port}"], timeout=8)
        transports = local_adb_transports(runner(executable, ["devices"], timeout=8))
    except (OSError, subprocess.TimeoutExpired, ValueError):
        result.update(status="command_error", message="Yerel ADB bağlantısı tamamlanamadı veya zaman aşımına uğradı.")
        return result
    states = set()
    for serial, state in transports:
        endpoint = _adb_local_endpoint(serial)
        if endpoint and endpoint[0] in ("127.0.0.1", "localhost") and endpoint[1] == port:
            states.add(state)
    if states == {"device"}:
        result.update(status="connected", message="İstenen yerel ADB bağlantısı cihaz listesinde doğrulandı.")
    elif "unauthorized" in states:
        result.update(status="unauthorized", message="Yerel emülatör ADB yetkilendirmesi bekliyor; bağlantı kullanıma hazır değil.")
    elif "offline" in states:
        result.update(status="offline", message="Yerel emülatör ADB listesinde çevrimdışı; bağlantı kullanıma hazır değil.")
    elif states:
        result.update(status="not_ready", message="Yerel ADB bağlantısı listelendi ancak cihaz durumunda değil.")
    else:
        result.update(status="not_connected", message="İstenen yerel port için bağlı bir ADB cihazı doğrulanamadı.")
    return result


"""Read package/version metadata through an existing local emulator ADB setup."""
import json
import os
import re
import subprocess
from pathlib import Path

PUBG_PACKAGES = ("com.tencent.ig", "com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm", "com.pubg.imobile")


def adb_command(executable, arguments, timeout=12):
    """No shell, connection scanning, root request, package writes, or raw output logging."""
    completed = subprocess.run([str(executable), *arguments], stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               timeout=timeout, creationflags=0x08000000 if os.name == "nt" else 0)
    if len(completed.stdout) > 2 * 1024 * 1024:
        raise ValueError("ADB yanıtı boyut sınırını aşıyor.")
    if completed.returncode:
        raise ValueError(f"ADB komutu tamamlanamadı (kod {completed.returncode}).")
    return completed.stdout.decode("utf-8", errors="replace")


def local_adb_devices(text):
    """Only select loopback/standard-emulator transports; never query attached phones."""
    return _ready_local_transports(local_adb_transports(text))


def _ready_local_transports(transports):
    states = {}
    for serial, state in transports:
        states.setdefault(serial, set()).add(state)
    return [serial for serial, values in states.items() if values == {"device"}]


def package_metadata(package, output):
    if package not in PUBG_PACKAGES:
        raise ValueError("Desteklenmeyen paket adı.")
    version = re.search(r"\bversionName=([^\s]+)", output)
    if not version:
        return None
    code = re.search(r"\bversionCode=(\d+)", output)
    abi = re.search(r"\bprimaryCpuAbi=([^\s]+)", output)
    secondary_abi = re.search(r"\bsecondaryCpuAbi=([^\s]+)", output)
    result = {"package": package, "version_name": version.group(1)[:60],
              "version_code": code.group(1) if code else None,
              "package_primary_abi": abi.group(1)[:40] if abi and abi.group(1) != "null" else None,
              "package_secondary_abi": secondary_abi.group(1)[:40] if secondary_abi and secondary_abi.group(1) != "null" else None}
    return result


def adb_library_range(executable, serial, path, offset, size):
    """Read only a small aligned part of an on-disk UE4 library via normal ADB."""
    if not re.fullmatch(r"/[A-Za-z0-9_./=+@~:-]+/libUE4\.so", path) or ".." in path.split("/"):
        raise ValueError("Kütüphane yolu geçersiz.")
    if type(offset) is not int or type(size) is not int or not 0 <= offset <= 512 * 1024 * 1024 or not 1 <= size <= 65536:
        raise ValueError("Kütüphane okuma sınırı aşıldı.")
    block = 4096
    padding = offset % block
    count = (padding + size + block - 1) // block
    args = [str(executable), "-s", serial, "exec-out", "dd", f"if={path}",
            f"bs={block}", f"skip={offset // block}", f"count={count}"]
    completed = subprocess.run(args, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, timeout=8,
                               creationflags=0x08000000 if os.name == "nt" else 0)
    if completed.returncode or len(completed.stdout) > count * block:
        raise ValueError("Kütüphane normal ADB izinleriyle okunamadı.")
    return completed.stdout[padding:padding + size]


def probe_engine_library(executable, serial, package_output, pid_text, runner, binary_reader=adb_library_range):
    result = {"status": "unavailable", "mapped_library": False, "mappings": [], "errors": []}
    mappings = []
    pids = pid_text.split() if re.fullmatch(r"\d+(?:\s+\d+)*", pid_text or "") else []
    if pids:
        try:
            maps_text = runner(executable, ["-s", serial, "shell", "cat", f"/proc/{int(pids[0])}/maps"], timeout=8)
            mappings = parse_ue4_maps(maps_text)
            result["mappings"] = [row.to_report() for row in mappings]
            result["mapped_library"] = any(not row.deleted for row in mappings)
        except (OSError, subprocess.TimeoutExpired, ValueError):
            result["errors"].append("Oyun modül listesi normal ADB izinleriyle okunamadı.")
    match = re.search(r"\bnativeLibraryDir=([^\s]+)", package_output)
    native_dir = match.group(1) if match else None
    candidates = engine_library_candidates(native_dir, mappings)
    for path, source in candidates:
        try:
            info = metadata_from_reader(lambda offset, size: binary_reader(executable, serial, path, offset, size))
        except (OSError, subprocess.TimeoutExpired, ValueError):
            continue
        result.update({"status": "available", "metadata_source": source, **info})
        return result
    result["errors"].append("libUE4.so başlığı/derleme kimliği normal dosya izinleriyle okunamadı veya dosya bulunamadı.")
    return result


def probe_adb(executable, runner=adb_command, binary_reader=adb_library_range):
    result = {"status": "unavailable", "local_device_count": 0, "packages": [], "errors": []}
    if not executable:
        result["errors"].append("Kurulu ADB bulunamadı. İstersen ADB seç düğmesiyle kurulu adb.exe dosyasını seçebilirsin.")
        return result
    try:
        transports = local_adb_transports(runner(executable, ["devices"]))
        devices = _ready_local_transports(transports)
    except (OSError, subprocess.TimeoutExpired, ValueError):
        result["errors"].append("ADB başlatılamadı veya zaman aşımına uğradı.")
        return result
    result["local_transport_states"] = summarize_local_transports(transports)
    try:
        result["client_version"] = parse_adb_version(runner(executable, ["version"], timeout=5))
    except (OSError, subprocess.TimeoutExpired, ValueError):
        result["client_version"] = {"protocol_version": None, "package_version": None}
    result["local_device_count"] = len(devices)
    if not devices:
        states = result["local_transport_states"]
        if states.get("unauthorized"):
            result["status"] = "unauthorized"
            result["errors"].append("Yerel emülatör ADB izni bekliyor. Emülatörde varsa hata ayıklama izin penceresini kontrol edin.")
        elif states.get("offline"):
            result["status"] = "offline"
            result["errors"].append("Yerel ADB bağlantısı listede var, ancak çevrimdışı. Bağla + test ile durumunu yeniden kontrol edebilirsiniz.")
        elif transports:
            result["status"] = "not_ready"
            result["errors"].append("Yerel ADB bağlantısı henüz hazır değil.")
        else:
            result["errors"].append("ADB yerel emülatör listesi boş. Gameloop açıkken ADB'yi bağla + test seçeneğini deneyebilirsiniz.")
        return result
    if len(devices) != 1:
        result["status"] = "ambiguous"
        result["errors"].append("Birden çok yerel emülatör bağlı. Diğer emülatörleri kapatıp yeniden dene.")
        return result
    serial = devices[0]
    result["status"] = "connected"
    prefix = ["-s", serial, "shell"]
    try:
        # Device ABI is labelled separately; it does not prove the game package ABI.
        abi = runner(executable, prefix + ["getprop", "ro.product.cpu.abi"]).strip()
        result["emulator_primary_abi"] = abi[:40] if re.fullmatch(r"[A-Za-z0-9_-]{1,40}", abi) else None
    except (OSError, subprocess.TimeoutExpired, ValueError):
        result["errors"].append("Emülatör mimarisi okunamadı.")
    for package in PUBG_PACKAGES:
        try:
            package_output = runner(executable, prefix + ["dumpsys", "package", package])
            info = package_metadata(package, package_output)
            if info is None:
                continue
            pid_text = ""
            try:
                pid_text = runner(executable, prefix + ["pidof", package], timeout=5).strip()
                info["running"] = bool(re.fullmatch(r"\d+(?:\s+\d+)*", pid_text))
            except (OSError, subprocess.TimeoutExpired, ValueError):
                info["running"] = None
            info["engine_library"] = probe_engine_library(executable, serial, package_output, pid_text,
                                                          runner, binary_reader)
            result["packages"].append(info)
        except (OSError, subprocess.TimeoutExpired, ValueError):
            result["errors"].append(f"{package} paket bilgisi okunamadı.")
    if not result["packages"]:
        result["errors"].append("Bağlı emülatörde desteklenen PUBG paketi bulunamadı.")
    return result


def inspect_elf_header(path):
    """Inspect a local library through the same bounded parser as the ADB probe."""
    with open(path, "rb") as stream:
        file_size = os.fstat(stream.fileno()).st_size
        def read_range(offset, size):
            if offset + size > file_size:
                raise ValueError("ELF dosya sınırı aşıldı.")
            stream.seek(offset)
            return stream.read(size)
        return metadata_from_reader(read_range)



import argparse
import copy
from datetime import datetime, timezone
import queue
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


def collect_report(explicit_adb=None, reconnect_port=None):
    native = probe_gameloop_processes()
    processes = native["processes"]
    candidates = find_adb_candidates(processes, explicit_adb)
    reconnection = None
    if reconnect_port is not None:
        if native["supported"] and processes and candidates:
            reconnection = reconnect_local_adb(candidates[0], reconnect_port, adb_command)
        else:
            reconnection = {"attempted": False, "port": None, "status": "unavailable",
                            "message": "Bağlantı için Windows, çalışan Gameloop süreci ve geçerli ADB dosyası gerekiyor."}
    adb = probe_adb(candidates[0] if candidates else None) if native["supported"] else {
        "status": "unsupported", "local_device_count": 0, "packages": [], "errors": ["Canlı Gameloop testi Windows gerektirir."]}
    adb["selection"] = "explicit" if explicit_adb is not None else "automatic"
    if reconnection is not None:
        adb["reconnection"] = reconnection
    return {"tool": "Miran Gameloop Connection Test", "report_version": 3, "tool_version": "0.3",
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "python_bits": ctypes.sizeof(ctypes.c_void_p) * 8,
            "windows_supported": native["supported"],
            "processes": [process.to_report() for process in processes],
            "process_errors": native["errors"], "adb": adb,
            "esp": {"implemented": False, "player_data_connected": False,
                    "reason": "Ölçülen oyun derlemesine uygun oyuncu/kamera adresleri ve engel kontrolü henüz doğrulanmadı."}}


def report_summary(report):
    lines = ["BAĞLANTI / SÜRÜM RAPORU", ""]
    if not report["windows_supported"]:
        lines.append("Bu makine Windows değil; canlı Gameloop kontrolü yapılmadı.")
    processes = report["processes"]
    lines.append(f"Gameloop ile ilişkili Windows süreci: {len(processes)}")
    for process in processes:
        lines.append(f"  {process['name']} | PID {process['pid']} | Windows süreç mimarisi: {process['host_process_architecture']} | Dosya sürümü: {process['file_version'] or 'okunamadı'}")
    lines.extend(report["process_errors"])
    adb = report["adb"]
    lines.extend(["", f"ADB durumu: {adb['status']}", f"Bağlı yerel emülatör: {adb['local_device_count']}"])
    versions = adb.get("client_version", {})
    if versions.get("protocol_version") or versions.get("package_version"):
        lines.append(f"ADB istemcisi: {versions.get('protocol_version') or '?'} / {versions.get('package_version') or '?'}")
    states = adb.get("local_transport_states", {})
    if states:
        lines.append(f"Yerel durumlar: hazır {states.get('device', 0)}, çevrimdışı {states.get('offline', 0)}, izin bekleyen {states.get('unauthorized', 0)}, diğer {states.get('other', 0)}")
    if adb.get("reconnection"):
        lines.append("Bağlantı denemesi: " + adb["reconnection"]["message"])
    if adb.get("emulator_primary_abi"):
        lines.append("Emülatör ABI: " + adb["emulator_primary_abi"])
    for package in adb["packages"]:
        running = "çalışıyor" if package.get("running") is True else ("çalışmıyor" if package.get("running") is False else "çalışma durumu okunamadı")
        lines.append(f"  {package['package']} | PUBG {package['version_name']} | Paket ABI: {package['package_primary_abi'] or 'okunamadı'} | {running}")
        engine = package.get("engine_library", {})
        if engine.get("status") == "available":
            lines.append(f"  UE4 ELF: {engine['elf_bits']} bit / {engine['machine']} | Kaynak: {engine['metadata_source']}")
            if engine.get("gnu_build_id"):
                lines.append("  UE4 GNU Build ID: " + engine["gnu_build_id"])
        lines.append("  Yüklenmiş UE4 modülü: " + ("eşleşme bulundu" if engine.get("mapped_library") else "doğrulanamadı"))
        lines.extend("  " + error for error in engine.get("errors", []))
    lines.extend(adb["errors"])
    if report.get("selected_library"):
        lib = report["selected_library"]
        lines.extend(["", f"Seçilen ELF: {lib['elf_bits']} bit / {lib['machine']}", "Bu bilgi tek başına 4.6.1 sürüm uyumluluğunu doğrulamaz."])
        if lib.get("gnu_build_id"):
            lines.append("ELF GNU Build ID: " + lib["gnu_build_id"])
    lines.extend(["", "ESP oyuncu verisi bağlı değil. Bu paket bağlantı tanısı içindir; oyuncu kutusu çizmez.",
                  "Windows sürecinin 64 bit olması, PUBG'nin kendi ELF mimarisini tek başına kanıtlamaz."])
    return "\n".join(lines)


class LiveTestWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("MİRAN Gameloop — bağlantı ve derleme testi v3")
        self.root.geometry("960x680")
        self.root.minsize(760, 480)
        self.queue = queue.SimpleQueue()
        self.stop = threading.Event()
        self.busy = False
        self.report = None
        self.adb_path = None
        self.library = None
        self.adb_port = tk.StringVar(value="5555")
        frame = ttk.Frame(root, padding=14)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Gameloop / PUBG derleme testi v3", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Tanılama paketi • ESP henüz uygulanmadı; gerçek oyuncu göstermez.", foreground="#a32929").pack(anchor="w", pady=(4, 12))
        ttk.Label(frame, text="Gameloop ve PUBG'yi aç, ardından Testi başlat'a bas. ADB zaman aşımlarında işlem birkaç dakika sürebilir.", wraplength=820).pack(anchor="w")
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=10)
        self.run_button = ttk.Button(buttons, text="Testi başlat", command=self.run)
        self.run_button.pack(side="left")
        ttk.Button(buttons, text="Kurulu ADB seç", command=self.choose_adb).pack(side="left", padx=6)
        ttk.Button(buttons, text="LibUE4 dosyası incele (isteğe bağlı)", command=self.choose_library).pack(side="left")
        ttk.Button(buttons, text="Raporu kaydet", command=self.save_report).pack(side="right")
        reconnect_bar = ttk.Frame(frame)
        reconnect_bar.pack(fill="x", pady=(0, 4))
        ttk.Label(reconnect_bar, text="Yerel ADB portu:").pack(side="left")
        ttk.Entry(reconnect_bar, textvariable=self.adb_port, width=7).pack(side="left", padx=6)
        self.connect_button = ttk.Button(reconnect_bar, text="ADB'yi bağla + test", command=lambda: self.run(reconnect=True))
        self.connect_button.pack(side="left")
        ttk.Label(frame, text="5555 varsayılan adaydır; bağlantı doğrulanmış değildir. Bu düğme yalnızca bilgisayarındaki 127.0.0.1 adresine bağlanmayı dener.", wraplength=880).pack(anchor="w", pady=(0, 10))
        text_frame = ttk.Frame(frame)
        text_frame.pack(fill="both", expand=True)
        self.text = tk.Text(text_frame, wrap="word", font=("Consolas", 10), state="disabled")
        self.text.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(text_frame, command=self.text.yview)
        scroll.pack(side="right", fill="y")
        self.text.configure(yscrollcommand=scroll.set)
        self.status = tk.StringVar(value="Hazır. Henüz kontrol yapılmadı.")
        ttk.Label(frame, textvariable=self.status, wraplength=820).pack(anchor="w", pady=(10, 0))
        self.write("Bu sürüm süreç, paket sürümü, UE4 ELF mimarisi ve varsa GNU Build ID bilgisini toplar.\nNormal ADB izinleri yeterliyse oyunun UE4 modül eşlemelerini de sorgular.\nİzin reddinde root veya koruma aşma denemez. ESP oyuncu verisi henüz bağlı değildir.\n\nRapor tam kurulum yolu, cihaz seri numarası veya hesap bilgisi içermez.")
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.after_id = self.root.after(50, self.drain)

    def write(self, text):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", text)
        self.text.configure(state="disabled")

    def run(self, reconnect=False):
        if self.busy:
            return
        reconnect_port = None
        if reconnect:
            try:
                reconnect_port = _adb_valid_port(self.adb_port.get().strip())
            except ValueError as exc:
                messagebox.showerror("ADB portu", str(exc), parent=self.root)
                return
        self.busy = True
        self.run_button.configure(state="disabled")
        self.connect_button.configure(state="disabled")
        self.status.set("Süreçler, PUBG paketi ve erişilebilen UE4 derleme bilgisi okunuyor…")
        adb_path = self.adb_path
        def worker():
            try:
                result = collect_report(adb_path, reconnect_port)
            except Exception:
                if not self.stop.is_set():
                    self.queue.put(("error", "Tanılama tamamlanamadı. Gameloop'u açıp yeniden dene."))
            else:
                if not self.stop.is_set():
                    self.queue.put(("result", result))
        threading.Thread(target=worker, daemon=True, name="MiranDiagnosis").start()

    def drain(self):
        try:
            kind, value = self.queue.get_nowait()
        except queue.Empty:
            pass
        else:
            self.busy = False
            self.run_button.configure(state="normal")
            self.connect_button.configure(state="normal")
            if kind == "error":
                self.status.set(value)
            else:
                self.report = value
                if self.library:
                    self.report["selected_library"] = copy.deepcopy(self.library)
                self.write(report_summary(self.report))
                self.status.set("Kontrol tamamlandı. Raporu kaydet ile sonucu JSON olarak saklayabilirsin.")
        if not self.stop.is_set():
            self.after_id = self.root.after(50, self.drain)

    def choose_adb(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(parent=self.root, title="Kurulu adb.exe dosyasını seç", filetypes=[("ADB", "adb.exe"), ("Tümü", "*.*")])
        if path:
            if Path(path).name.lower() not in ("adb.exe", "adb"):
                messagebox.showerror("ADB seçimi", "Kurulu adb.exe dosyasını seçin.", parent=self.root)
                return
            self.adb_path = path
            self.status.set("ADB dosyası seçildi. Testi yeniden başlatabilirsin.")

    def choose_library(self):
        path = filedialog.askopenfilename(parent=self.root, title="Yerel libUE4.so dosyası seç", filetypes=[("ELF kütüphanesi", "*.so"), ("Tümü", "*.*")])
        if not path:
            return
        try:
            self.library = inspect_elf_header(path)
        except (OSError, ValueError) as exc:
            messagebox.showerror("ELF inceleme", str(exc), parent=self.root)
            return
        if self.report:
            self.report["selected_library"] = copy.deepcopy(self.library)
            self.write(report_summary(self.report))
        self.status.set(f"Kütüphane mimarisi: {self.library['elf_bits']} bit / {self.library['machine']}")

    def save_report(self):
        if not self.report:
            messagebox.showinfo("Rapor", "Önce Testi başlat düğmesiyle kontrol yapın.", parent=self.root)
            return
        path = filedialog.asksaveasfilename(parent=self.root, initialfile="miran_gameloop_rapor.json", defaultextension=".json", filetypes=[("JSON raporu", "*.json")])
        if path:
            try:
                Path(path).write_text(json.dumps(self.report, ensure_ascii=False, indent=2), encoding="utf-8")
            except OSError:
                messagebox.showerror("Rapor", "Rapor yazılamadı; yazılabilir bir klasör seçin.", parent=self.root)
                return
            self.status.set("Rapor kaydedildi. Sonraki inceleme için bu JSON dosyasını paylaşabilirsin.")

    def close(self):
        self.stop.set()
        self.root.after_cancel(self.after_id)
        self.root.destroy()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Gameloop/PUBG bağlantı ve mimari tanısı. ESP içermez.")
    parser.add_argument("--check", action="store_true", help="Arayüz açmadan raporu yazdır")
    parser.add_argument("--adb", help="Kurulu ADB dosyasının yolu")
    args = parser.parse_args(argv)
    if args.check:
        print(json.dumps(collect_report(args.adb), ensure_ascii=False, indent=2))
        return 0
    root = tk.Tk()
    LiveTestWindow(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
