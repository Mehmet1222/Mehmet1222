# MİRAN Gameloop bağlantı testi

Bu ilk paket **tanılama uygulamasıdır**. PUBG 4.6.1 için ESP oyuncu okuma ve
engel kontrolü henüz uygulanmadı; uygulama oyuncu kutusu çizmez.
Önceki test panelinden farklı olarak örnek oyuncu üretmez. Windows üzerinde
kurulu Gameloop'un gerçek süreç bilgilerini ve varsa mevcut yerel ADB
bağlantısından PUBG paket bilgilerini sorgular.

## Çalıştırma

1. Windows'ta Python 3.10 veya üzeri, Tcl/Tk desteğiyle kurulu olmalıdır.
2. ZIP dosyasını bir klasöre çıkar.
3. Gameloop'u aç ve PUBG Mobile'ı başlat.
4. `BASLAT_GAMELOOP_TEST.bat` dosyasına çift tıkla.
5. **Testi başlat** düğmesine bas.
6. İşlem bitince **Raporu kaydet** ile `miran_gameloop_rapor.json` dosyasını kaydet.
   Sonraki inceleme için bu dosyayı sohbette paylaşabilirsin.

Terminalden de çalıştırılabilir:

```powershell
py miran_gameloop_tani.py
```

Ek Python paketi gerekmez. Yönetici izni otomatik istenmez.

## Ölçülen bilgiler

- Seçili Gameloop süreçlerinin adı, PID'si, **Windows süreç mimarisi** ve dosya sürümü.
- Kurulu ADB bulunabiliyorsa bağlı yerel emülatör sayısı.
- Tek bir yerel emülatör bağlıysa bilinen PUBG paketlerinin sürümü, paket ABI'si
  ve okunabildiğinde oyunun çalışıyor olup olmadığı.
- İsteğe bağlı seçilen yerel `libUE4.so` dosyasının ELF mimarisi ve varsa GNU Build ID.

Windows sürecinin x64 olması, Android içindeki PUBG paketinin AArch64 olduğunu
tek başına kanıtlamaz. Program bu iki bilgiyi ayrı etiketlerle gösterir.
Bir ELF dosyasının 64 bit olması veya Build ID'si de tek başına oyun sürümü ve
ESP adreslerinin uyumlu olduğunu kanıtlamaz.

Uygulamada belirtilen hedef `4.6.1 / 64 bit`, kullanıcının verdiği bilgidir;
ölçülen PUBG paket bilgileri raporda ayrıca yer alır.

## ADB bulunamazsa

Uygulama PATH ile Gameloop kurulumunun bilinen yakın dizinlerinde mevcut ADB'yi
arar. Kurulu ADB farklı yerdeyse **Kurulu ADB seç** ile mevcut `adb.exe` dosyasını
seçip testi yeniden başlatabilirsin. Programa rastgele bir yürütülebilir dosya
seçme; mevcut Android Debug Bridge dosyasını kullan.

Gameloop'un mevcut ADB bağlantısı etkin değilse uygulama bunu raporlar. Bağlantı
portlarını taramaz, emülatör ayarlarını değiştirmez veya korumaları aşmaya çalışmaz.
ADB'nin normal istemci başlatması yerel ADB sunucusunu başlatabilir.
Birden çok yerel emülatör bağlıysa diğerlerini kapatıp testi yeniden dene.
USB telefonlar ve uzak ağ adresleri otomatik sorguya alınmaz.

## Rapor ve sınırlar

Rapor tam kurulum yollarını, Windows kullanıcı adını, ADB cihaz seri numarasını
ve hesap bilgilerini kaydetmez. Raporu kullanıcı seçtiği konuma kaydeder;
uygulama rapor yüklemez. Oyun belleğine yazmaz, oyuna patch uygulamaz ve sürücü
yüklemez. Varsayılan iş akışı `libUE4.so` dosyasını çıkarmaya da çalışmaz.

Bu rapor bağlantı ve derleme eşleştirmesinin ilk adımıdır. Raporun başarılı olması
ESP'nin hazır olduğu anlamına gelmez. Gerçek oyuncu konumları, kamera dönüşümü
ve engel görünürlüğü için 4.6.1 derlemesiyle doğrulanmış veri erişimi hâlâ gerekir.

## Geliştirici kontrolü

```powershell
py -m unittest -v test_native_metadata.py test_live_app.py
py miran_gameloop_tani.py --check
```

19 otomatik test Linux ortamında geçti. Arayüz sanal ekranda açıldı; işçi kuyruğu,
rapor gösterimi, JSON kaydı ve kapanış kontrol edildi. Windows rapor görünümü
taklit metadata ile sınandı. **Gerçek Windows API çağrıları, ADB ve Gameloop
bağlantısı bu ortamda denenmedi.**
