import json
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
from unittest.mock import Mock, patch
import miran_gameloop_tani as app


class LiveAppTests(unittest.TestCase):
    def test_only_local_emulators_selected_without_phone_serials(self):
        text = "List of devices attached\nUSBPHONE123 device\n127.0.0.1:5555 device\n127.0.0.1:5555 device\nemulator-5554 offline\n192.168.1.5:5555 device\nlocalhost:5556 device"
        self.assertEqual(app.local_adb_devices(text), ["127.0.0.1:5555", "localhost:5556"])

    def test_package_metadata_extracts_version_and_package_abi_only(self):
        output = "versionName=4.6.1\nversionCode=40601 minSdk=21\nprimaryCpuAbi=arm64-v8a\nuserId=12345\ncodePath=/data/private/file\n"
        info = app.package_metadata("com.tencent.ig", output)
        self.assertEqual(info["version_name"], "4.6.1")
        self.assertEqual(info["package_primary_abi"], "arm64-v8a")
        self.assertNotIn("private", json.dumps(info))
        self.assertNotIn("12345", json.dumps(info))
        self.assertIsNone(app.package_metadata("com.tencent.ig", "package not found"))

    def test_no_queries_run_when_no_local_emulator(self):
        runner = Mock(return_value="USBPHONE device\n")
        result = app.probe_adb("adb.exe", runner)
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(runner.call_count, 1)

    def test_ambiguous_devices_not_queried(self):
        runner = Mock(return_value="127.0.0.1:5555 device\nemulator-5554 device")
        self.assertEqual(app.probe_adb("adb.exe", runner)["status"], "ambiguous")
        self.assertEqual(runner.call_count, 1)

    def test_adb_only_reads_known_metadata_and_excludes_serial(self):
        commands = []
        def runner(executable, arguments, timeout=12):
            commands.append(arguments)
            if arguments == ["devices"]:
                return "127.0.0.1:5555 device\n"
            if "getprop" in arguments:
                return "x86_64\n"
            if "pidof" in arguments:
                return "1234\n"
            return "versionName=4.6.1\nversionCode=1\nprimaryCpuAbi=arm64-v8a" if arguments[-1] == "com.tencent.ig" else "package not found"
        result = app.probe_adb("adb.exe", runner)
        self.assertEqual(result["status"], "connected")
        self.assertEqual(len(result["packages"]), 1)
        self.assertTrue(result["packages"][0]["running"])
        self.assertEqual(result["emulator_primary_abi"], "x86_64")
        self.assertEqual(result["packages"][0]["package_primary_abi"], "arm64-v8a")
        self.assertNotIn("127.0.0.1", json.dumps(result))
        for command in commands:
            self.assertFalse({"root", "connect", "push", "install", "su"}.intersection(command))

    def test_adb_error_output_not_disclosed(self):
        runner = Mock(side_effect=subprocess.TimeoutExpired("C:/Users/PRIVATE/adb.exe", 12))
        result = app.probe_adb("adb.exe", runner)
        self.assertNotIn("PRIVATE", json.dumps(result))
        self.assertEqual(result["status"], "unavailable")

    def test_report_summary_handles_native_report_schema(self):
        native = {"supported": True, "processes": [app.ProcessInfo(100, "aow_exe.exe", "x64", "7.1.1.1", "C:/Users/PRIVATE/adb.exe")], "errors": []}
        with patch.object(app, "probe_gameloop_processes", return_value=native), patch.object(app, "find_adb_candidates", return_value=[]):
            report = app.collect_report()
        summary = app.report_summary(report)
        self.assertIn("7.1.1.1", summary)
        self.assertIn("Windows süreç mimarisi: x64", summary)
        self.assertNotIn("PRIVATE", json.dumps(report))
        self.assertFalse(report["esp"]["implemented"])
        self.assertFalse(report["esp"]["player_data_connected"])

    def test_elf_class_and_gnu_build_id_without_loading_library(self):
        header = bytearray(64)
        header[:7] = b"\x7fELF\x02\x01\x01"
        struct.pack_into("<H", header, 18, 183)
        struct.pack_into("<Q", header, 32, 64)
        struct.pack_into("<HH", header, 54, 56, 1)
        program = bytearray(56)
        struct.pack_into("<I", program, 0, 4)
        struct.pack_into("<Q", program, 8, 120)
        notes = struct.pack("<III", 4, 4, 3) + b"GNU\0" + b"\xde\xad\xbe\xef"
        struct.pack_into("<Q", program, 32, len(notes))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "libUE4.so"
            path.write_bytes(header + program + notes)
            result = app.inspect_elf_header(path)
        self.assertEqual(result["elf_bits"], 64)
        self.assertEqual(result["machine"], "AArch64")
        self.assertEqual(result["gnu_build_id"], "deadbeef")
        self.assertFalse(result["build_version_verified"])

    def test_truncated_and_non_elf_files_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.so"
            for content in (b"not an elf", b"\x7fELF\x02\x01" + bytes(20)):
                path.write_bytes(content)
                with self.assertRaises(ValueError):
                    app.inspect_elf_header(path)

    def test_untrusted_elf_table_cannot_seek_outside_file(self):
        header = bytearray(64)
        header[:7] = b"\x7fELF\x02\x01\x01"
        struct.pack_into("<Q", header, 32, 2**64 - 1)
        struct.pack_into("<HH", header, 54, 56, 1)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.so"
            path.write_bytes(header)
            with self.assertRaisesRegex(ValueError, "sınır"):
                app.inspect_elf_header(path)


if __name__ == "__main__":
    unittest.main()
