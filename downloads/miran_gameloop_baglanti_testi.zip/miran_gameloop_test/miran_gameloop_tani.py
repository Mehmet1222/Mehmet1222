"""Read-only Windows metadata for known GameLoop processes.

Only QUERY_LIMITED_INFORMATION handles are requested. The reported architecture
belongs to the Windows host process; it does not establish the Android guest
game's architecture. No game memory is opened or scanned.
"""

import ctypes
from dataclasses import dataclass, field
import os
from pathlib import Path
import shutil


_WP_DWORD = ctypes.c_uint32
_WP_LONG = ctypes.c_int32
_WP_WORD = ctypes.c_uint16
_WP_ULONG_PTR = ctypes.c_size_t
_WP_HANDLE = ctypes.c_void_p


class _WP_PROCESSENTRY32W(ctypes.Structure):
    # WCHAR is always UTF-16 on Windows; c_wchar is wider on some test hosts.
    _fields_ = [
        ("dwSize", _WP_DWORD), ("cntUsage", _WP_DWORD),
        ("th32ProcessID", _WP_DWORD), ("th32DefaultHeapID", _WP_ULONG_PTR),
        ("th32ModuleID", _WP_DWORD), ("cntThreads", _WP_DWORD),
        ("th32ParentProcessID", _WP_DWORD), ("pcPriClassBase", _WP_LONG),
        ("dwFlags", _WP_DWORD), ("szExeFile", _WP_WORD * 260),
    ]


class _WP_SYSTEM_INFO(ctypes.Structure):
    _fields_ = [
        ("wProcessorArchitecture", _WP_WORD), ("wReserved", _WP_WORD),
        ("dwPageSize", _WP_DWORD),
        ("lpMinimumApplicationAddress", ctypes.c_void_p),
        ("lpMaximumApplicationAddress", ctypes.c_void_p),
        ("dwActiveProcessorMask", _WP_ULONG_PTR),
        ("dwNumberOfProcessors", _WP_DWORD), ("dwProcessorType", _WP_DWORD),
        ("dwAllocationGranularity", _WP_DWORD),
        ("wProcessorLevel", _WP_WORD), ("wProcessorRevision", _WP_WORD),
    ]


class _WP_VS_FIXEDFILEINFO(ctypes.Structure):
    _fields_ = [(name, _WP_DWORD) for name in (
        "dwSignature", "dwStrucVersion", "dwFileVersionMS", "dwFileVersionLS",
        "dwProductVersionMS", "dwProductVersionLS", "dwFileFlagsMask",
        "dwFileFlags", "dwFileOS", "dwFileType", "dwFileSubtype",
        "dwFileDateMS", "dwFileDateLS",
    )]


GAMELOOP_PROCESS_NAMES = frozenset(name.casefold() for name in (
    "aow_exe.exe", "AndroidEmulator.exe", "AndroidEmulatorEn.exe",
    "AndroidEmulatorEx.exe", "AndroidEmulatorExEn.exe",
    "QMEmulatorService.exe", "AppMarket.exe", "TBoxSvc.exe",
))


@dataclass(frozen=True)
class ProcessInfo:
    pid: int
    name: str
    architecture: str = "unknown"
    version: str | None = None
    path: str | None = field(default=None, repr=False)

    def to_report(self):
        """Exclude installation paths, which may contain a Windows user name."""
        return {
            "pid": self.pid,
            "name": self.name,
            "host_process_architecture": self.architecture,
            "file_version": self.version,
        }


def _wp_decode_name(array):
    return bytes(array).decode("utf-16-le", errors="replace").split("\x00", 1)[0]


def _wp_machine_name(machine):
    return {0x014C: "x86", 0x8664: "x64", 0xAA64: "arm64", 0x01C4: "arm32"}.get(machine, "unknown")


def _wp_bind_kernel32():
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.CreateToolhelp32Snapshot.argtypes = [_WP_DWORD, _WP_DWORD]
    kernel.CreateToolhelp32Snapshot.restype = _WP_HANDLE
    kernel.Process32FirstW.argtypes = [_WP_HANDLE, ctypes.POINTER(_WP_PROCESSENTRY32W)]
    kernel.Process32FirstW.restype = ctypes.c_int
    kernel.Process32NextW.argtypes = [_WP_HANDLE, ctypes.POINTER(_WP_PROCESSENTRY32W)]
    kernel.Process32NextW.restype = ctypes.c_int
    kernel.OpenProcess.argtypes = [_WP_DWORD, ctypes.c_int, _WP_DWORD]
    kernel.OpenProcess.restype = _WP_HANDLE
    kernel.CloseHandle.argtypes = [_WP_HANDLE]
    kernel.CloseHandle.restype = ctypes.c_int
    kernel.QueryFullProcessImageNameW.argtypes = [
        _WP_HANDLE, _WP_DWORD, ctypes.POINTER(ctypes.c_wchar), ctypes.POINTER(_WP_DWORD),
    ]
    kernel.QueryFullProcessImageNameW.restype = ctypes.c_int
    if hasattr(kernel, "IsWow64Process2"):
        kernel.IsWow64Process2.argtypes = [
            _WP_HANDLE, ctypes.POINTER(_WP_WORD), ctypes.POINTER(_WP_WORD),
        ]
        kernel.IsWow64Process2.restype = ctypes.c_int
    kernel.IsWow64Process.argtypes = [_WP_HANDLE, ctypes.POINTER(ctypes.c_int)]
    kernel.IsWow64Process.restype = ctypes.c_int
    kernel.GetNativeSystemInfo.argtypes = [ctypes.POINTER(_WP_SYSTEM_INFO)]
    kernel.GetNativeSystemInfo.restype = None
    return kernel


def _wp_process_architecture(kernel, handle):
    if hasattr(kernel, "IsWow64Process2"):
        process_machine, native_machine = _WP_WORD(), _WP_WORD()
        if kernel.IsWow64Process2(handle, ctypes.byref(process_machine), ctypes.byref(native_machine)):
            return _wp_machine_name(process_machine.value or native_machine.value)
    wow64 = ctypes.c_int()
    if not kernel.IsWow64Process(handle, ctypes.byref(wow64)):
        return "unknown"
    if wow64.value:
        return "x86"
    native = _WP_SYSTEM_INFO()
    kernel.GetNativeSystemInfo(ctypes.byref(native))
    return {0: "x86", 9: "x64", 12: "arm64", 5: "arm32"}.get(native.wProcessorArchitecture, "unknown")


def _wp_file_version(path):
    """Read the executable's fixed file-version resource, when available."""
    if not path:
        return None
    version = ctypes.WinDLL("version", use_last_error=True)
    version.GetFileVersionInfoSizeW.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(_WP_DWORD)]
    version.GetFileVersionInfoSizeW.restype = _WP_DWORD
    version.GetFileVersionInfoW.argtypes = [ctypes.c_wchar_p, _WP_DWORD, _WP_DWORD, ctypes.c_void_p]
    version.GetFileVersionInfoW.restype = ctypes.c_int
    version.VerQueryValueW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_uint)]
    version.VerQueryValueW.restype = ctypes.c_int
    ignored = _WP_DWORD()
    size = version.GetFileVersionInfoSizeW(path, ctypes.byref(ignored))
    if not size or size > 16 * 1024 * 1024:
        return None
    buffer = ctypes.create_string_buffer(size)
    if not version.GetFileVersionInfoW(path, 0, size, buffer):
        return None
    pointer, length = ctypes.c_void_p(), ctypes.c_uint()
    if not version.VerQueryValueW(buffer, "\\", ctypes.byref(pointer), ctypes.byref(length)):
        return None
    if not pointer.value or length.value < ctypes.sizeof(_WP_VS_FIXEDFILEINFO):
        return None
    info = ctypes.cast(pointer, ctypes.POINTER(_WP_VS_FIXEDFILEINFO)).contents
    if info.dwSignature != 0xFEEF04BD:
        return None
    return ".".join(str(part) for part in (
        info.dwFileVersionMS >> 16, info.dwFileVersionMS & 0xFFFF,
        info.dwFileVersionLS >> 16, info.dwFileVersionLS & 0xFFFF,
    ))


def probe_gameloop_processes():
    """Return supported/processes/errors; processes are ProcessInfo instances.

    Access-denied processes remain listed, with unknown optional metadata. Only
    known GameLoop image names are queried. All messages omit full image paths.
    """
    if os.name != "nt":
        return {"supported": False, "processes": [], "errors": ["Windows süreç bilgisi bu platformda kullanılamıyor."]}
    processes, errors = [], []
    try:
        kernel = _wp_bind_kernel32()
    except (AttributeError, OSError) as exc:
        return {"supported": True, "processes": [], "errors": [f"Windows süreç API'si kullanılamadı ({type(exc).__name__})."]}
    snapshot = kernel.CreateToolhelp32Snapshot(0x00000002, 0)
    if snapshot in (None, ctypes.c_void_p(-1).value):
        return {"supported": True, "processes": [], "errors": [f"Süreç listesi alınamadı (Win32 {ctypes.get_last_error()})."]}
    try:
        entry = _WP_PROCESSENTRY32W()
        entry.dwSize = ctypes.sizeof(entry)
        success = kernel.Process32FirstW(snapshot, ctypes.byref(entry))
        while success:
            name = _wp_decode_name(entry.szExeFile)
            if name.casefold() in GAMELOOP_PROCESS_NAMES:
                pid = int(entry.th32ProcessID)
                path = None
                architecture = "unknown"
                file_version = None
                handle = kernel.OpenProcess(0x1000, False, pid)
                if handle:
                    try:
                        length = _WP_DWORD(32768)
                        image = ctypes.create_unicode_buffer(length.value)
                        if kernel.QueryFullProcessImageNameW(handle, 0, image, ctypes.byref(length)):
                            path = image.value
                        architecture = _wp_process_architecture(kernel, handle)
                    finally:
                        kernel.CloseHandle(handle)
                    try:
                        file_version = _wp_file_version(path)
                    except (OSError, AttributeError, ValueError):
                        pass
                else:
                    errors.append(f"PID {pid}: sınırlı süreç sorgusu reddedildi; mimari/sürüm bilinmiyor.")
                processes.append(ProcessInfo(pid, name, architecture, file_version, path))
            success = kernel.Process32NextW(snapshot, ctypes.byref(entry))
        error = ctypes.get_last_error()
        if error not in (0, 18):  # ERROR_NO_MORE_FILES is a normal end-of-snapshot.
            errors.append(f"Süreç listesi tamamlanamadı (Win32 {error}).")
    finally:
        kernel.CloseHandle(snapshot)
    processes.sort(key=lambda item: (item.name.casefold(), item.pid))
    return {"supported": True, "processes": processes, "errors": errors}


def find_adb_candidates(processes, explicit=None):
    """Find existing adb paths without recursive filesystem or network discovery."""
    requested = []
    if explicit is not None:
        requested.append(Path(explicit))
    located = shutil.which("adb.exe") or shutil.which("adb")
    if located:
        requested.append(Path(located))
    relative = (
        "adb.exe", "adb", "ui/adb.exe", "AppMarket/adb.exe",
        "AndroidEmulator/adb.exe", "AndroidTbox/adb.exe", "aow_drv/adb.exe",
        "aow_drv/Android/adb.exe", "aow_drv/Android/DebugBridge/adb.exe",
    )
    for process in list(processes)[:32]:
        if not process.path:
            continue
        # At most three installation ancestors and nine known relative names.
        for ancestor in list(Path(process.path).parents)[:3]:
            requested.extend(ancestor / suffix for suffix in relative)
    found, seen = [], set()
    for candidate in requested:
        try:
            if candidate.name.casefold() not in {"adb.exe", "adb"} or not candidate.is_file():
                continue
            resolved = candidate.resolve(strict=True)
            key = os.path.normcase(str(resolved))
            if key not in seen:
                found.append(str(resolved))
                seen.add(key)
        except (OSError, RuntimeError, ValueError):
            continue
    return found


"""Read package/version metadata through an existing local emulator ADB setup."""
import json
import os
import re
import subprocess
from pathlib import Path

PUBG_PACKAGES = ("com.tencent.ig", "com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm", "com.pubg.imobile")


def adb_command(executable, arguments, timeout=12):
    """No shell, connection scanning, root request, package writes, or raw output logging."""
    completed = subprocess.run([str(executable), *arguments], stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               timeout=timeout, creationflags=0x08000000 if os.name == "nt" else 0)
    if len(completed.stdout) > 2 * 1024 * 1024:
        raise ValueError("ADB yanıtı boyut sınırını aşıyor.")
    if completed.returncode:
        raise ValueError(f"ADB komutu tamamlanamadı (kod {completed.returncode}).")
    return completed.stdout.decode("utf-8", errors="replace")


def local_adb_devices(text):
    """Only select loopback/standard-emulator transports; never query attached phones."""
    devices = []
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 2 or parts[1] != "device":
            continue
        serial = parts[0]
        if re.fullmatch(r"(?:127\.0\.0\.1|localhost):[0-9]{1,5}|emulator-[0-9]+", serial):
            devices.append(serial)
    return list(dict.fromkeys(devices))


def package_metadata(package, output):
    if package not in PUBG_PACKAGES:
        raise ValueError("Desteklenmeyen paket adı.")
    version = re.search(r"\bversionName=([^\s]+)", output)
    if not version:
        return None
    code = re.search(r"\bversionCode=(\d+)", output)
    abi = re.search(r"\bprimaryCpuAbi=([^\s]+)", output)
    result = {"package": package, "version_name": version.group(1)[:60],
              "version_code": code.group(1) if code else None,
              "package_primary_abi": abi.group(1)[:40] if abi and abi.group(1) != "null" else None}
    return result


def probe_adb(executable, runner=adb_command):
    result = {"status": "unavailable", "local_device_count": 0, "packages": [], "errors": []}
    if not executable:
        result["errors"].append("Kurulu ADB bulunamadı. İstersen ADB seç düğmesiyle kurulu adb.exe dosyasını seçebilirsin.")
        return result
    try:
        devices = local_adb_devices(runner(executable, ["devices"]))
    except (OSError, subprocess.TimeoutExpired, ValueError):
        result["errors"].append("ADB başlatılamadı veya zaman aşımına uğradı.")
        return result
    result["local_device_count"] = len(devices)
    if not devices:
        result["errors"].append("Bağlı yerel emülatör yok. Gameloop'un mevcut ADB bağlantısı etkin olmalı.")
        return result
    if len(devices) != 1:
        result["status"] = "ambiguous"
        result["errors"].append("Birden çok yerel emülatör bağlı. Diğer emülatörleri kapatıp yeniden dene.")
        return result
    serial = devices[0]
    result["status"] = "connected"
    prefix = ["-s", serial, "shell"]
    try:
        # Device ABI is labelled separately; it does not prove the game package ABI.
        abi = runner(executable, prefix + ["getprop", "ro.product.cpu.abi"]).strip()
        result["emulator_primary_abi"] = abi[:40] if re.fullmatch(r"[A-Za-z0-9_-]{1,40}", abi) else None
    except (OSError, subprocess.TimeoutExpired, ValueError):
        result["errors"].append("Emülatör mimarisi okunamadı.")
    for package in PUBG_PACKAGES:
        try:
            info = package_metadata(package, runner(executable, prefix + ["dumpsys", "package", package]))
            if info is None:
                continue
            try:
                pid_text = runner(executable, prefix + ["pidof", package], timeout=5).strip()
                info["running"] = bool(re.fullmatch(r"\d+(?:\s+\d+)*", pid_text))
            except (OSError, subprocess.TimeoutExpired, ValueError):
                info["running"] = None
            result["packages"].append(info)
        except (OSError, subprocess.TimeoutExpired, ValueError):
            result["errors"].append(f"{package} paket bilgisi okunamadı.")
    if not result["packages"]:
        result["errors"].append("Bağlı emülatörde desteklenen PUBG paketi bulunamadı.")
    return result


def inspect_elf_header(path):
    """Identify a user-selected ELF library without loading or executing it."""
    with open(path, "rb") as stream:
        header = stream.read(64)
    if len(header) < 20 or header[:4] != b"\x7fELF":
        raise ValueError("Seçilen dosya geçerli bir ELF kütüphanesi değil.")
    if header[4] not in (1, 2) or header[5] not in (1, 2):
        raise ValueError("ELF sınıfı veya byte sırası desteklenmiyor.")
    bits = 32 if header[4] == 1 else 64
    if len(header) < (64 if bits == 64 else 52):
        raise ValueError("ELF başlığı eksik.")
    endian = "little" if header[5] == 1 else "big"
    machine = int.from_bytes(header[18:20], endian)
    build_id = None
    phoff = int.from_bytes(header[32:40] if bits == 64 else header[28:32], endian)
    phsize = int.from_bytes(header[54:56] if bits == 64 else header[42:44], endian)
    phcount = int.from_bytes(header[56:58] if bits == 64 else header[44:46], endian)
    if phcount > 1024 or (phcount and phsize < (56 if bits == 64 else 32)):
        raise ValueError("ELF program başlığı tablosu geçersiz.")
    with open(path, "rb") as stream:
        file_size = os.fstat(stream.fileno()).st_size
        if phcount and phoff + phcount * phsize > file_size:
            raise ValueError("ELF program başlığı tablosu dosya sınırını aşıyor.")
        for index in range(phcount):
            stream.seek(phoff + index * phsize)
            entry = stream.read(56 if bits == 64 else 32)
            if len(entry) < (56 if bits == 64 else 32):
                raise ValueError("ELF program başlığı tablosu eksik.")
            if int.from_bytes(entry[:4], endian) != 4:  # PT_NOTE
                continue
            offset = int.from_bytes(entry[8:16] if bits == 64 else entry[4:8], endian)
            size = int.from_bytes(entry[32:40] if bits == 64 else entry[16:20], endian)
            if size > 1024 * 1024:
                continue
            if offset + size > file_size:
                raise ValueError("ELF not bölümü dosya sınırını aşıyor.")
            stream.seek(offset)
            notes = stream.read(size)
            cursor = 0
            while cursor + 12 <= len(notes):
                namesize = int.from_bytes(notes[cursor:cursor + 4], endian)
                descsize = int.from_bytes(notes[cursor + 4:cursor + 8], endian)
                note_type = int.from_bytes(notes[cursor + 8:cursor + 12], endian)
                cursor += 12
                desc_start = cursor + ((namesize + 3) & ~3)
                if desc_start + descsize > len(notes):
                    break
                if notes[cursor:cursor + namesize].rstrip(b"\0") == b"GNU" and note_type == 3 and 1 <= descsize <= 128:
                    build_id = notes[desc_start:desc_start + descsize].hex()
                    break
                cursor = desc_start + ((descsize + 3) & ~3)
            if build_id:
                break
    return {"elf_bits": 32 if header[4] == 1 else 64,
            "machine": {40: "ARM", 183: "AArch64", 3: "x86", 62: "x86_64"}.get(machine, f"unknown:{machine}"),
            "gnu_build_id": build_id,
            "build_version_verified": False}


import argparse
import copy
from datetime import datetime, timezone
import queue
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox


def collect_report(explicit_adb=None):
    native = probe_gameloop_processes()
    processes = native["processes"]
    candidates = find_adb_candidates(processes, explicit_adb)
    adb = probe_adb(candidates[0] if candidates else None) if native["supported"] else {
        "status": "unsupported", "local_device_count": 0, "packages": [], "errors": ["Canlı Gameloop testi Windows gerektirir."]}
    return {"tool": "Miran Gameloop Connection Test", "report_version": 1,
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "python_bits": ctypes.sizeof(ctypes.c_void_p) * 8,
            "windows_supported": native["supported"],
            "processes": [process.to_report() for process in processes],
            "process_errors": native["errors"], "adb": adb,
            "declared_target": {"pubg_version": "4.6.1", "game_bits": 64},
            "esp": {"implemented": False, "player_data_connected": False,
                    "reason": "4.6.1 için doğrulanmış oyuncu/kamera adresleri ve engel kontrolü henüz yok."}}


def report_summary(report):
    lines = ["BAĞLANTI / SÜRÜM RAPORU", ""]
    if not report["windows_supported"]:
        lines.append("Bu makine Windows değil; canlı Gameloop kontrolü yapılmadı.")
    processes = report["processes"]
    lines.append(f"Gameloop ile ilişkili Windows süreci: {len(processes)}")
    for process in processes:
        lines.append(f"  {process['name']} | PID {process['pid']} | Windows süreç mimarisi: {process['host_process_architecture']} | Dosya sürümü: {process['file_version'] or 'okunamadı'}")
    lines.extend(report["process_errors"])
    adb = report["adb"]
    lines.extend(["", f"ADB durumu: {adb['status']}", f"Bağlı yerel emülatör: {adb['local_device_count']}"])
    if adb.get("emulator_primary_abi"):
        lines.append("Emülatör ABI: " + adb["emulator_primary_abi"])
    for package in adb["packages"]:
        running = "çalışıyor" if package.get("running") is True else ("çalışmıyor" if package.get("running") is False else "çalışma durumu okunamadı")
        lines.append(f"  {package['package']} | PUBG {package['version_name']} | Paket ABI: {package['package_primary_abi'] or 'okunamadı'} | {running}")
    lines.extend(adb["errors"])
    if report.get("selected_library"):
        lib = report["selected_library"]
        lines.extend(["", f"Seçilen ELF: {lib['elf_bits']} bit / {lib['machine']}", "Bu bilgi tek başına 4.6.1 sürüm uyumluluğunu doğrulamaz."])
        if lib.get("gnu_build_id"):
            lines.append("ELF GNU Build ID: " + lib["gnu_build_id"])
    lines.extend(["", "ESP oyuncu verisi bağlı değil. Bu paket bağlantı tanısı içindir; oyuncu kutusu çizmez.",
                  "Windows sürecinin 64 bit olması, PUBG'nin kendi ELF mimarisini tek başına kanıtlamaz."])
    return "\n".join(lines)


class LiveTestWindow:
    def __init__(self, root):
        self.root = root
        self.root.title("MİRAN Gameloop — bağlantı testi")
        self.root.geometry("900x620")
        self.root.minsize(680, 440)
        self.queue = queue.SimpleQueue()
        self.stop = threading.Event()
        self.busy = False
        self.report = None
        self.adb_path = None
        self.library = None
        frame = ttk.Frame(root, padding=14)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="Gameloop / PUBG 4.6.1 bağlantı testi", font=("Segoe UI", 16, "bold")).pack(anchor="w")
        ttk.Label(frame, text="İlk tanılama paketi • ESP henüz uygulanmadı; gerçek oyuncu göstermez.", foreground="#a32929").pack(anchor="w", pady=(4, 12))
        ttk.Label(frame, text="Gameloop ve PUBG'yi aç, ardından Testi başlat'a bas. İşlem yaklaşık 1 dakika sürebilir.", wraplength=820).pack(anchor="w")
        buttons = ttk.Frame(frame)
        buttons.pack(fill="x", pady=10)
        self.run_button = ttk.Button(buttons, text="Testi başlat", command=self.run)
        self.run_button.pack(side="left")
        ttk.Button(buttons, text="Kurulu ADB seç", command=self.choose_adb).pack(side="left", padx=6)
        ttk.Button(buttons, text="LibUE4 dosyası incele (isteğe bağlı)", command=self.choose_library).pack(side="left")
        ttk.Button(buttons, text="Raporu kaydet", command=self.save_report).pack(side="right")
        text_frame = ttk.Frame(frame)
        text_frame.pack(fill="both", expand=True)
        self.text = tk.Text(text_frame, wrap="word", font=("Consolas", 10), state="disabled")
        self.text.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(text_frame, command=self.text.yview)
        scroll.pack(side="right", fill="y")
        self.text.configure(yscrollcommand=scroll.set)
        self.status = tk.StringVar(value="Hazır. Henüz kontrol yapılmadı.")
        ttk.Label(frame, textvariable=self.status, wraplength=820).pack(anchor="w", pady=(10, 0))
        self.write("Bu uygulama süreç, sürüm ve mimari bilgisi toplar.\nOyun belleğine yama yazmaz; korumaları veya emülatör ayarlarını değiştirmez.\n\nRapor kullanıcı adı, tam dosya yolu, cihaz seri numarası veya hesap bilgisi içermez.")
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        self.after_id = self.root.after(50, self.drain)

    def write(self, text):
        self.text.configure(state="normal")
        self.text.delete("1.0", "end")
        self.text.insert("1.0", text)
        self.text.configure(state="disabled")

    def run(self):
        if self.busy:
            return
        self.busy = True
        self.run_button.configure(state="disabled")
        self.status.set("Windows süreçleri ve mevcut ADB bağlantısı kontrol ediliyor…")
        adb_path = self.adb_path
        def worker():
            try:
                result = collect_report(adb_path)
            except Exception:
                if not self.stop.is_set():
                    self.queue.put(("error", "Tanılama tamamlanamadı. Gameloop'u açıp yeniden dene."))
            else:
                if not self.stop.is_set():
                    self.queue.put(("result", result))
        threading.Thread(target=worker, daemon=True, name="MiranDiagnosis").start()

    def drain(self):
        try:
            kind, value = self.queue.get_nowait()
        except queue.Empty:
            pass
        else:
            self.busy = False
            self.run_button.configure(state="normal")
            if kind == "error":
                self.status.set(value)
            else:
                self.report = value
                if self.library:
                    self.report["selected_library"] = copy.deepcopy(self.library)
                self.write(report_summary(self.report))
                self.status.set("Kontrol tamamlandı. Raporu kaydet ile sonucu JSON olarak saklayabilirsin.")
        if not self.stop.is_set():
            self.after_id = self.root.after(50, self.drain)

    def choose_adb(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(parent=self.root, title="Kurulu adb.exe dosyasını seç", filetypes=[("ADB", "adb.exe"), ("Tümü", "*.*")])
        if path:
            if Path(path).name.lower() not in ("adb.exe", "adb"):
                messagebox.showerror("ADB seçimi", "Kurulu adb.exe dosyasını seçin.", parent=self.root)
                return
            self.adb_path = path
            self.status.set("ADB dosyası seçildi. Testi yeniden başlatabilirsin.")

    def choose_library(self):
        path = filedialog.askopenfilename(parent=self.root, title="Yerel libUE4.so dosyası seç", filetypes=[("ELF kütüphanesi", "*.so"), ("Tümü", "*.*")])
        if not path:
            return
        try:
            self.library = inspect_elf_header(path)
        except (OSError, ValueError) as exc:
            messagebox.showerror("ELF inceleme", str(exc), parent=self.root)
            return
        if self.report:
            self.report["selected_library"] = copy.deepcopy(self.library)
            self.write(report_summary(self.report))
        self.status.set(f"Kütüphane mimarisi: {self.library['elf_bits']} bit / {self.library['machine']}")

    def save_report(self):
        if not self.report:
            messagebox.showinfo("Rapor", "Önce Testi başlat düğmesiyle kontrol yapın.", parent=self.root)
            return
        path = filedialog.asksaveasfilename(parent=self.root, initialfile="miran_gameloop_rapor.json", defaultextension=".json", filetypes=[("JSON raporu", "*.json")])
        if path:
            try:
                Path(path).write_text(json.dumps(self.report, ensure_ascii=False, indent=2), encoding="utf-8")
            except OSError:
                messagebox.showerror("Rapor", "Rapor yazılamadı; yazılabilir bir klasör seçin.", parent=self.root)
                return
            self.status.set("Rapor kaydedildi. Sonraki inceleme için bu JSON dosyasını paylaşabilirsin.")

    def close(self):
        self.stop.set()
        self.root.after_cancel(self.after_id)
        self.root.destroy()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Gameloop/PUBG bağlantı ve mimari tanısı. ESP içermez.")
    parser.add_argument("--check", action="store_true", help="Arayüz açmadan raporu yazdır")
    parser.add_argument("--adb", help="Kurulu ADB dosyasının yolu")
    args = parser.parse_args(argv)
    if args.check:
        print(json.dumps(collect_report(args.adb), ensure_ascii=False, indent=2))
        return 0
    root = tk.Tk()
    LiveTestWindow(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
