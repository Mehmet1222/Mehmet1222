# MİRAN Gameloop bağlantı ve derleme testi v2

Bu sürüm **tanılama aracıdır; ESP oyuncu okuma ve çizimi henüz uygulanmadı**.
Kurmaca oyuncu üretmez. Mevcut Gameloop/ADB bağlantısından ölçüm yapar.

## Çalıştırma

1. ZIP'i tamamen yeni bir klasöre çıkar.
2. Python 3.10+ ve Tcl/Tk desteği kurulu olmalıdır; ek Python paketi gerekmez.
3. Gameloop ve PUBG'yi aç.
4. `BASLAT_GAMELOOP_TEST.bat` dosyasını çalıştır.
5. **Testi başlat**, ardından **Raporu kaydet** seçeneğini kullan.
6. Yeni `miran_gameloop_rapor.json` dosyasını inceleme için paylaşabilirsin.

## v2 ölçümleri

- Windows Gameloop süreçlerinin dosya sürümü ve host mimarisi.
- Bağlı tek yerel emülatördeki PUBG paket sürümü, birincil/ikincil paket ABI'si.
- Oyun açıkken normal ADB izinleriyle erişilebiliyorsa `libUE4.so` modül eşlemeleri.
- Normal dosya izinleriyle okunabiliyorsa UE4 dosyasının gerçek ELF32/ELF64
  mimarisi, makine türü ve mevcut GNU Build ID'si.

Eşleme listesi alınamıyorsa paket kütüphane dizini aday olarak kontrol edilir.
Raporda `metadata_source: native_library_dir`, bunun yüklenmiş dosyayla aynı
olduğunu iddia etmez. `metadata_source: mapped` ise eşleme listesindeki dosya
yolundan okunduğunu gösterir. Silinmiş dosyalar okuma adayı yapılmaz. APK içinden
doğrudan eşlenen kütüphaneler bu sürümde açılmaz.

İzin reddi halinde root, `su`, koruma aşma veya geniş bellek taraması denenmez.
ELF okuması aday başına toplam 256 KiB, çağrı başına 64 KiB ile sınırlıdır;
tam kütüphane kopyalanmaz ve çalıştırılmaz. Dosya aralığı 512 MiB ile sınırlıdır.
Okunan aralıklar ADB `dd` komutunda 4 KiB bloklara hizalandığından fiziksel
aktarım ayrıştırıcının kullandığı bayt sayısından biraz büyük olabilir.

## Sürüm ve mimariyi yorumlama

Windows `aow_exe.exe` sürecinin x64 olması, PUBG'nin ARM64 olduğunu kanıtlamaz.
Paket `armeabi-v7a` olarak seçilmişse paket ABI'si ARMv7/32 bittir; gerçek
`libUE4.so` mimarisi ayrıca ELF başlığıyla kontrol edilir.

Önceki v1 raporundaki `declared_target` sabit kullanıcı beyanıydı. **v2 bu alanı
kaldırır**; ölçülen paket bilgileri `adb.packages` altında bulunur. Paket sürümü
oyun içi kaynak/hotfix etiketinden farklı olabilir.

GNU Build ID, tek başına oyuncu adreslerini veya ESP uyumluluğunu sağlamaz.
Bu raporla derleme eşleştirmesi yapılabilir; oyuncu/kamera verisi ve gerçek
engel testi ayrıca uygulanıp doğrulanmalıdır.

## Rapor içeriği

Rapor hesap bilgisi, cihaz seri numarası veya tam dosya yolu içermez. UE4
eşlemelerinde yalnızca modül basename'i, adres aralığı, dosya offset'i, izinler
ve silinmiş olma durumu bulunur. Program raporu kendiliğinden yüklemez.

## Kontroller

```powershell
py -m unittest -v test_native_metadata test_live_app test_engine_metadata test_engine_integration
py miran_gameloop_tani.py --check
```

41 otomatik test Linux ortamında geçti. Tkinter arayüzü sanal ekranda açıldı;
ELF32/ARM rapor görünümü, işçi kuyruğu, JSON kaydı ve kapanış sınandı. Windows
raporları bu kontrolde taklit verilerle gösterildi. Gerçek Windows, Gameloop,
ADB `dd` ve hedef dosya izinleri bu ortamdan doğrulanamadı.
