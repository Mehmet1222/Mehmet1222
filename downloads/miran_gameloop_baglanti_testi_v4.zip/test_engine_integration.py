import struct
import subprocess
import unittest
from unittest.mock import Mock, patch
import miran_gameloop_tani as app


def elf32_bytes():
    header = bytearray(52)
    header[:7] = b"\x7fELF\x01\x01\x01"
    struct.pack_into("<H", header, 18, 40)
    struct.pack_into("<I", header, 20, 1)
    struct.pack_into("<H", header, 40, 52)
    return bytes(header)


class EngineIntegrationTests(unittest.TestCase):
    def test_remote_range_uses_bounded_dd_and_exact_slice(self):
        output = bytes(index % 256 for index in range(8192))
        result = Mock(returncode=0, stdout=output)
        with patch.object(app.subprocess, "run", return_value=result) as run:
            data = app.adb_library_range("adb.exe", "127.0.0.1:5555", "/data/app/lib/arm/libUE4.so", 4090, 64)
        self.assertEqual(data, output[4090:4154])
        arguments = run.call_args.args[0]
        self.assertIn("exec-out", arguments)
        self.assertIn("skip=0", arguments)
        self.assertIn("count=2", arguments)
        self.assertNotIn("shell=True", str(run.call_args))
        self.assertEqual(run.call_args.kwargs["timeout"], 8)

    def test_remote_range_rejects_shell_syntax_and_unbounded_reads(self):
        for path, offset, size in [("/data/../libUE4.so", 0, 64), ("/data/libUE4.so;su", 0, 64),
                                   ("/data/libUE4.so", -1, 64), ("/data/libUE4.so", 0, 65537),
                                   ("/data/libUE4.so", True, 64)]:
            with self.subTest(path=path, offset=offset, size=size), patch.object(app.subprocess, "run") as run:
                with self.assertRaises(ValueError):
                    app.adb_library_range("adb.exe", "emulator-5554", path, offset, size)
                run.assert_not_called()

    def test_probe_reads_actual_elf_and_redacts_private_path(self):
        maps = "100000-101000 r-xp 00000000 00:00 0 /data/private/libUE4.so\n"
        runner = Mock(return_value=maps)
        blob = elf32_bytes()
        calls = []
        def binary_reader(exe, serial, path, offset, size):
            calls.append((path, offset, size))
            return blob[offset:offset + size]
        result = app.probe_engine_library("adb.exe", "emulator-5554", "nativeLibraryDir=/data/private", "123", runner, binary_reader)
        self.assertEqual(result["status"], "available")
        self.assertEqual(result["elf_bits"], 32)
        self.assertEqual(result["machine"], "ARM")
        self.assertTrue(result["mapped_library"])
        self.assertEqual(result["metadata_source"], "mapped")
        self.assertNotIn("/data/private", str(result))
        self.assertNotIn("emulator-5554", str(result))
        self.assertTrue(calls)

    def test_permission_denied_never_escalates_or_leaks_commands(self):
        runner = Mock(side_effect=ValueError("private pathname not for report"))
        binary = Mock(side_effect=PermissionError("private pathname"))
        result = app.probe_engine_library("adb.exe", "emulator-5554", "nativeLibraryDir=/data/private", "123", runner, binary)
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["read_attempts"][0]["error_code"], "permission_denied")
        self.assertNotIn("private", str(result))
        self.assertEqual(runner.call_count, 1)
        self.assertEqual(runner.call_args.args[1], ["-s", "emulator-5554", "shell", "cat", "/proc/123/maps"])

    def test_bad_elf_does_not_become_a_permission_error(self):
        result = app.probe_engine_library("adb.exe", "emulator-5554", "nativeLibraryDir=/data/private", "",
                                         Mock(), lambda exe, serial, path, offset, size: bytes(size))
        self.assertEqual(result["status"], "unavailable")
        self.assertEqual(result["read_attempts"][0]["error_code"], "elf_metadata_invalid")
        self.assertNotIn("permission_denied", str(result))
        self.assertNotIn("private", str(result))

    def test_missing_candidate_does_not_claim_permission_denial(self):
        binary = Mock()
        result = app.probe_engine_library("adb.exe", "emulator-5554", "", "", Mock(), binary)
        binary.assert_not_called()
        self.assertEqual(result["read_attempts"], [])
        self.assertIn("dosya yolu bulunamadı", result["errors"][0])

    def test_timeout_details_stay_private_and_have_specific_code(self):
        binary = Mock(side_effect=subprocess.TimeoutExpired("private command path", 8))
        result = app.probe_engine_library("adb.exe", "emulator-5554", "nativeLibraryDir=/data/private", "", Mock(), binary)
        self.assertEqual(result["read_attempts"][0]["error_code"], "timeout")
        self.assertNotIn("private", str(result))

    def test_successful_legacy_transport_is_reported(self):
        class LegacyBlock(bytes):
            method = "shell_hex"
        blob = elf32_bytes()
        result = app.probe_engine_library("adb.exe", "emulator-5554", "nativeLibraryDir=/data/private", "", Mock(),
                                         lambda exe, serial, path, offset, size: LegacyBlock(blob[offset:offset + size]))
        self.assertEqual(result["status"], "available")
        self.assertEqual(result["read_attempts"][0]["methods"], ["shell_hex"])
        self.assertFalse(result["mapped_library"])

    def test_structured_transport_error_survives_elf_wrapper(self):
        stages = [{"method": "exec_out", "status": "exec_out_unsupported"},
                  {"method": "shell_hex", "status": "command_unavailable"}]
        binary = Mock(side_effect=app.LibraryReadError("command_unavailable", stages))
        result = app.probe_engine_library("adb.exe", "emulator-5554", "nativeLibraryDir=/data/private", "", Mock(), binary)
        self.assertEqual(result["read_attempts"][0]["error_code"], "command_unavailable")
        self.assertEqual(result["read_attempts"][0]["transport_attempts"], stages)
        self.assertNotIn("private", str(result))

    def test_package_report_with_maps_denied_is_not_claimed_loaded(self):
        blob = elf32_bytes()
        result = app.probe_engine_library("adb.exe", "emulator-5554", "nativeLibraryDir=/data/private", "123",
                                         Mock(side_effect=PermissionError()),
                                         lambda exe, serial, path, offset, size: blob[offset:offset + size])
        self.assertEqual(result["status"], "available")
        self.assertEqual(result["metadata_source"], "native_library_dir")
        self.assertFalse(result["mapped_library"])
        self.assertFalse(result["build_version_verified"])


if __name__ == "__main__":
    unittest.main()
