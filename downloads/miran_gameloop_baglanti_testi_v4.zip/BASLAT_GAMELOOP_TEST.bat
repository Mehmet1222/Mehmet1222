@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python 3.10 veya uzeri ve Python Launcher gerekli.
  pause
  exit /b 1
)
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
  echo Python 3.10 veya uzeri gerekli.
  pause
  exit /b 1
)
py -3 "%~dp0miran_gameloop_tani.py" %*
if errorlevel 1 pause
