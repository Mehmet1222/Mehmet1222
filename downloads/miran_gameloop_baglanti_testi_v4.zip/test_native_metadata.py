"""Portable process-probe tests; Windows APIs are not exercised on Linux."""

import ctypes
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import miran_gameloop_tani as wp


class WindowsProbeTests(unittest.TestCase):
    def test_windows_abi_widths_and_process_entry_layout(self):
        self.assertEqual(ctypes.sizeof(wp._WP_DWORD), 4)
        self.assertEqual(ctypes.sizeof(wp._WP_LONG), 4)
        self.assertEqual(ctypes.sizeof(wp._WP_WORD), 2)
        self.assertEqual(ctypes.sizeof(wp._WP_PROCESSENTRY32W), 568 if ctypes.sizeof(ctypes.c_void_p) == 8 else 556)
        self.assertEqual(ctypes.sizeof(wp._WP_VS_FIXEDFILEINFO), 52)

    def test_utf16_process_name_decoding_handles_non_ascii_and_terminator(self):
        entry = wp._WP_PROCESSENTRY32W()
        encoded = "AndroidEmulatorEx.exe\x00IGNORE".encode("utf-16-le")
        for i in range(len(encoded) // 2):
            entry.szExeFile[i] = int.from_bytes(encoded[2*i:2*i+2], "little")
        self.assertEqual(wp._wp_decode_name(entry.szExeFile), "AndroidEmulatorEx.exe")

    def test_reports_and_repr_do_not_expose_installation_paths(self):
        process = wp.ProcessInfo(123, "aow_exe.exe", "x64", "7.1.2.3", r"C:\Users\PrivateName\GameLoop\aow_exe.exe")
        report = process.to_report()
        self.assertNotIn("PrivateName", json.dumps(report))
        self.assertNotIn("PrivateName", repr(process))
        self.assertNotIn("path", report)
        self.assertEqual(report["host_process_architecture"], "x64")
        self.assertEqual(report["file_version"], "7.1.2.3")

    def test_machine_types_do_not_conflate_host_with_guest(self):
        self.assertEqual(wp._wp_machine_name(0x8664), "x64")
        self.assertEqual(wp._wp_machine_name(0x014C), "x86")
        self.assertEqual(wp._wp_machine_name(0xAA64), "arm64")
        self.assertEqual(wp._wp_machine_name(123), "unknown")

    def test_nonwindows_probe_is_structured_and_does_not_load_dlls(self):
        with patch.object(wp.os, "name", "posix"), patch.object(wp, "_wp_bind_kernel32") as bind:
            report = wp.probe_gameloop_processes()
        self.assertFalse(report["supported"])
        self.assertEqual(report["processes"], [])
        self.assertTrue(report["errors"])
        bind.assert_not_called()

    def test_known_installation_neighbors_and_explicit_path_are_deduplicated(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(wp.shutil, "which", return_value=None):
            root = Path(directory)
            ui = root / "ui"
            ui.mkdir()
            executable = ui / "AndroidEmulatorEn.exe"
            executable.write_bytes(b"metadata-only fixture")
            adb = root / "adb.exe"
            adb.write_bytes(b"not executed")
            process = wp.ProcessInfo(1, executable.name, path=str(executable))
            result = wp.find_adb_candidates([process], explicit=adb)
            self.assertEqual(result, [str(adb.resolve())])

    def test_discovery_does_not_recurse_into_unknown_subdirectories(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(wp.shutil, "which", return_value=None):
            root = Path(directory)
            arbitrary = root / "private" / "deep" / "other"
            arbitrary.mkdir(parents=True)
            (arbitrary / "adb.exe").write_bytes(b"not executed")
            (root / "adb.exe").mkdir()  # A directory must not count as an executable.
            process = wp.ProcessInfo(1, "aow_exe.exe", path=str(root / "aow_exe.exe"))
            self.assertEqual(wp.find_adb_candidates([process]), [])

    def test_explicit_path_must_be_existing_adb_filename(self):
        with tempfile.TemporaryDirectory() as directory, patch.object(wp.shutil, "which", return_value=None):
            other = Path(directory) / "tool.exe"
            other.write_bytes(b"not executed")
            self.assertEqual(wp.find_adb_candidates([], explicit=other), [])
            self.assertEqual(wp.find_adb_candidates([], explicit=other.with_name("missing-adb.exe")), [])

    def test_metadata_read_requests_only_limited_query(self):
        # A static check guards against accidentally expanding this helper into a
        # process-memory scanner when the real Windows APIs cannot run here.
        source = Path(wp.__file__).read_text()
        self.assertIn("kernel.OpenProcess(0x1000, False, pid)", source)
        self.assertNotIn("ReadProcessMemory", source)
        self.assertNotIn("PROCESS_VM_READ", source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
