import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import Mock, patch
import miran_gameloop_tani as lt


class LibraryTransportTests(unittest.TestCase):
    def read(self, offset=0, size=16, path="/data/private/libUE4.so"):
        return lt.adb_library_range("adb.exe", "127.0.0.1:5555", path, offset, size)

    def result(self, stdout=b"", stderr=b"", returncode=0):
        return Mock(stdout=stdout, stderr=stderr, returncode=returncode)

    def frame(self, data, newline=b"\n", status=0):
        body = b" ".join(f"{byte:02x}".encode() for byte in data)
        return b"MIRAN_HEX_BEGIN" + newline + body + newline + b"MIRAN_HEX_END:" + str(status).encode() + newline

    def test_primary_returns_exact_unmodified_bytes(self):
        raw = bytes(range(256)) * 32
        with patch.object(lt.subprocess, "run", return_value=self.result(raw)) as run:
            data = self.read(4090, 64)
        self.assertEqual(data, raw[4090:4154])
        self.assertEqual(data.method, "exec_out")
        self.assertEqual(run.call_count, 1)
        self.assertIn("count=2", run.call_args.args[0])
        self.assertNotIn("shell", run.call_args.kwargs)

    def test_old_adb_falls_back_to_exact_hex(self):
        payload = b"\x7fELF\r\n\x00\x0a" * 2
        with patch.object(lt.subprocess, "run", side_effect=[
                self.result(stderr=b"error: unknown command exec-out", returncode=1), self.result(self.frame(payload, b"\r\n"))]) as run:
            data = self.read(size=len(payload))
        self.assertEqual(data, payload)
        self.assertEqual(data.method, "shell_hex")
        self.assertEqual(run.call_count, 2)
        self.assertEqual(data.attempts[0]["status"], "exec_out_unsupported")
        self.assertEqual(run.call_args.args[0][3], "shell")
        self.assertIn("-N 16", run.call_args.args[0][-1])

    def test_old_adb_usage_on_stdout_zero_exit_is_not_binary(self):
        with patch.object(lt.subprocess, "run", side_effect=[
                self.result(b"Android Debug Bridge version 1.0.31\nusage: adb ..."), self.result(self.frame(bytes(16))) ]):
            data = self.read()
        self.assertEqual(data.method, "shell_hex")

    def test_dd_statistics_contamination_falls_back_without_trimming(self):
        raw = bytes(4096) + b"1+0 records in\n1+0 records out\n"
        with patch.object(lt.subprocess, "run", side_effect=[self.result(raw), self.result(self.frame(bytes(16)))]) as run:
            data = self.read()
        self.assertEqual(data.attempts[0]["status"], "output_contaminated")
        self.assertEqual(run.call_count, 2)

    def test_permission_and_missing_file_stop_without_fallback(self):
        for diagnostic, code in [(b"dd: /data/private/libUE4.so: Permission denied", "permission_denied"),
                                 (b"dd: /data/private/libUE4.so: No such file or directory", "file_not_found")]:
            with self.subTest(code=code), patch.object(lt.subprocess, "run", return_value=self.result(stderr=diagnostic, returncode=1)) as run:
                with self.assertRaises(lt.LibraryReadError) as raised:
                    self.read()
                self.assertEqual(raised.exception.code, code)
                self.assertNotIn("private", str(raised.exception))
                self.assertNotIn("private", json.dumps(raised.exception.attempts))
                self.assertEqual(run.call_count, 1)

    def test_timeout_does_not_retry_or_leak_command(self):
        with patch.object(lt.subprocess, "run", side_effect=subprocess.TimeoutExpired("private command", 8)) as run:
            with self.assertRaises(lt.LibraryReadError) as raised:
                self.read()
        self.assertEqual(raised.exception.code, "timeout")
        self.assertNotIn("private", str(raised.exception))
        self.assertEqual(run.call_count, 1)

    def test_invalid_requests_never_launch_process(self):
        cases = [("/data/../libUE4.so", 0, 16), ("/data/libUE4.so;id", 0, 16),
                 ("/data//libUE4.so", 0, 16), ("/data/libUE4.so", True, 16),
                 ("/data/libUE4.so", -1, 16), ("/data/libUE4.so", 0, 65537),
                 ("/data/libUE4.so", 512*1024*1024, 16)]
        for path, offset, size in cases:
            with self.subTest(path=path, offset=offset, size=size), patch.object(lt.subprocess, "run") as run:
                with self.assertRaises(lt.LibraryReadError):
                    self.read(offset, size, path)
                run.assert_not_called()
        with patch.object(lt.subprocess, "run") as run:
            for serial in ("USBPHONE", "192.168.1.1:5555", "127.0.0.1:65536", "emulator-1;id"):
                with self.assertRaises(lt.LibraryReadError):
                    lt.adb_library_range("adb", serial, "/data/libUE4.so", 0, 16)
            run.assert_not_called()

    def test_hex_parser_rejects_errors_noise_and_truncation(self):
        for payload, code in [(b"noise\n" + self.frame(bytes(16)), "invalid_hex_output"),
                               (self.frame(bytes(15)), "short_read"),
                               (self.frame(bytes(17)), "invalid_hex_output"),
                               (self.frame(bytes(16)) + b"extra", "invalid_hex_output"),
                               (b"MIRAN_HEX_BEGIN\n0000000 7f 45\nMIRAN_HEX_END:0\n", "invalid_hex_output"),
                               (b"MIRAN_HEX_BEGIN\nod: unknown option\nMIRAN_HEX_END:1\n", "command_unavailable")]:
            with self.subTest(code=code):
                with self.assertRaises(lt.LibraryReadError) as raised:
                    lt._library_parse_hex(payload, 16)
                self.assertEqual(raised.exception.code, code)

    def test_legacy_failure_retains_both_sanitized_stages(self):
        with patch.object(lt.subprocess, "run", side_effect=[
                self.result(stderr=b"unknown command", returncode=1),
                self.result(b"MIRAN_HEX_BEGIN\nod: /private/file: Permission denied\nMIRAN_HEX_END:1\n")]):
            with self.assertRaises(lt.LibraryReadError) as raised:
                self.read()
        self.assertEqual(raised.exception.code, "permission_denied")
        self.assertEqual(len(raised.exception.attempts), 2)
        self.assertNotIn("private", str(raised.exception) + str(raised.exception.attempts))

    @unittest.skipUnless(os.name == "posix", "POSIX shell syntax check runs on Linux")
    def test_generated_shell_command_reads_real_file_exactly(self):
        # Exercise actual POSIX shell/od syntax with a temporary owned fixture.
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "libUE4.so"
            raw = bytes(range(256)) * 4
            path.write_bytes(raw)
            self.assertTrue(lt._library_request_valid("emulator-5554", str(path), 111, 273))
            result = subprocess.run(["sh", "-c", lt._library_hex_command(str(path), 111, 273)],
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=3, check=True)
            self.assertEqual(lt._library_parse_hex(result.stdout, 273), raw[111:384])
            self.assertEqual(path.read_bytes(), raw)


if __name__ == "__main__":
    unittest.main()
