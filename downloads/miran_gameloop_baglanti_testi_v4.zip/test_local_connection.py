import json
import subprocess
import unittest
from unittest.mock import Mock
import miran_gameloop_tani as at


class TransportParserTests(unittest.TestCase):
    def test_retains_local_states_and_excludes_phones_and_remote_hosts(self):
        text = """List of devices attached
USB_SECRET_PHONE device
127.0.0.1:5555 offline
localhost:5556 unauthorized
[::1]:5557 device
emulator-5554 device
192.168.0.4:5555 device
attacker.example:5555 device
127.0.0.1:5555 offline
"""
        parsed = at.local_adb_transports(text)
        self.assertEqual(parsed, [("127.0.0.1:5555", "offline"), ("localhost:5556", "unauthorized"),
                                  ("[::1]:5557", "device"), ("emulator-5554", "device")])
        summary = at.summarize_local_transports(parsed)
        self.assertEqual(summary, {"device": 2, "offline": 1, "unauthorized": 1, "other": 0})
        self.assertNotIn("SECRET", json.dumps(summary))
        self.assertNotIn("5555", json.dumps(summary))

    def test_port_bounds_and_exact_loopback_names(self):
        text = "\n".join(f"{serial} device" for serial in (
            "127.0.0.1:0", "127.0.0.1:65536", "[::1]:99999", "emulator-0",
            "127.0.0.1.attacker:5555", "127.1:5555", "[::2]:5555", "127.0.0.1:1", "localhost:65535"))
        self.assertEqual(at.local_adb_transports(text), [("127.0.0.1:1", "device"), ("localhost:65535", "device")])

    def test_unknown_state_is_counted_without_echoing_raw_text(self):
        parsed = at.local_adb_transports("127.0.0.1:5555 no permissions\nlocalhost:5556 PRIVATE/PATH")
        self.assertEqual(at.summarize_local_transports(parsed)["other"], 2)
        self.assertNotIn("PRIVATE", str(parsed))

    def test_rows_and_text_are_bounded(self):
        parsed = at.local_adb_transports("\n".join(f"127.0.0.1:{port} device" for port in range(1, 200)))
        self.assertEqual(len(parsed), at.ADB_TRANSPORT_ROW_LIMIT)
        with self.assertRaises(ValueError):
            at.local_adb_transports("x" * (at.ADB_TRANSPORT_TEXT_LIMIT + 1))
        with self.assertRaises(ValueError):
            at.local_adb_transports("ü" * (at.ADB_TRANSPORT_TEXT_LIMIT // 2 + 1))
        with self.assertRaises(ValueError):
            at.local_adb_transports(None)

    def test_version_report_omits_installed_path_and_host_information(self):
        parsed = at.parse_adb_version("Android Debug Bridge version 1.0.41\r\nVersion 35.0.2-12147458\r\nInstalled as C:/Users/PRIVATE/adb.exe\r\nRunning on PRIVATEHOST\r\n")
        self.assertEqual(parsed, {"protocol_version": "1.0.41", "package_version": "35.0.2-12147458"})
        self.assertNotIn("PRIVATE", json.dumps(parsed))
        self.assertEqual(at.parse_adb_version("Installed as /PRIVATE\nVersion /PRIVATE"),
                         {"protocol_version": None, "package_version": None})


class ReconnectTests(unittest.TestCase):
    def test_one_connection_then_device_verification(self):
        runner = Mock(side_effect=["connected to 127.0.0.1:5555", "127.0.0.1:5555 device\n"])
        result = at.reconnect_local_adb("adb.exe", "5555", runner)
        self.assertEqual(result["status"], "connected")
        self.assertTrue(result["attempted"])
        self.assertEqual(result["port"], 5555)
        self.assertEqual([call.args[1] for call in runner.call_args_list], [["connect", "127.0.0.1:5555"], ["devices"]])
        self.assertTrue(all(call.kwargs == {"timeout": 8} for call in runner.call_args_list))
        self.assertNotIn("127.0.0.1", json.dumps(result))

    def test_connect_success_message_does_not_override_offline_or_unauthorized(self):
        for state in ("offline", "unauthorized"):
            with self.subTest(state=state):
                runner = Mock(side_effect=["already connected", f"127.0.0.1:5555 {state}"])
                self.assertEqual(at.reconnect_local_adb("adb.exe", 5555, runner)["status"], state)

    def test_unsolicited_different_transport_never_counts_as_success(self):
        for devices in ("127.0.0.1:5556 device", "emulator-5554 device", "[::1]:5555 device", "USB_PHONE device"):
            with self.subTest(devices=devices):
                runner = Mock(side_effect=["connected", devices])
                self.assertEqual(at.reconnect_local_adb("adb.exe", 5555, runner)["status"], "not_connected")

    def test_localhost_same_port_is_recognized_and_unknown_state_is_not_ready(self):
        runner = Mock(side_effect=["", "localhost:5555 device"])
        self.assertEqual(at.reconnect_local_adb("adb.exe", 5555, runner)["status"], "connected")
        runner = Mock(side_effect=["", "127.0.0.1:5555 recovery"])
        self.assertEqual(at.reconnect_local_adb("adb.exe", 5555, runner)["status"], "not_ready")

    def test_conflicting_target_states_do_not_claim_connection(self):
        runner = Mock(side_effect=["", "127.0.0.1:5555 device\n127.0.0.1:5555 offline"])
        self.assertEqual(at.reconnect_local_adb("adb.exe", 5555, runner)["status"], "offline")

    def test_invalid_port_never_runs_any_command(self):
        for port in (True, False, None, 0, 65536, 5555.0, "5555;su", "localhost:5555", " 5555", "５５５５", "-1", ""):
            with self.subTest(port=port):
                runner = Mock()
                result = at.reconnect_local_adb("adb.exe", port, runner)
                self.assertEqual(result["status"], "invalid_port")
                self.assertFalse(result["attempted"])
                runner.assert_not_called()

    def test_boundary_ports_and_leading_zeros_normalize(self):
        for value, expected in ((1, 1), (65535, 65535), ("05555", 5555)):
            with self.subTest(value=value):
                runner = Mock(side_effect=["", f"127.0.0.1:{expected} device"])
                result = at.reconnect_local_adb("adb.exe", value, runner)
                self.assertEqual(result["status"], "connected")
                self.assertEqual(result["port"], expected)

    def test_timeouts_errors_and_oversize_responses_are_redacted_and_not_retried(self):
        for error in (OSError("C:/Users/PRIVATE/adb.exe"), ValueError("SECRET RESPONSE"), subprocess.TimeoutExpired("PRIVATE COMMAND", 8)):
            with self.subTest(error=type(error).__name__):
                runner = Mock(side_effect=error)
                result = at.reconnect_local_adb("adb.exe", 5555, runner)
                self.assertEqual(result["status"], "command_error")
                self.assertEqual(runner.call_count, 1)
                self.assertNotIn("PRIVATE", json.dumps(result))
                self.assertNotIn("SECRET", json.dumps(result))
        runner = Mock(side_effect=["", "x" * (at.ADB_TRANSPORT_TEXT_LIMIT + 1)])
        self.assertEqual(at.reconnect_local_adb("adb.exe", 5555, runner)["status"], "command_error")
        self.assertEqual(runner.call_count, 2)

    def test_missing_executable_does_not_attempt_connection(self):
        runner = Mock()
        result = at.reconnect_local_adb(None, 5555, runner)
        self.assertEqual(result["status"], "command_error")
        self.assertFalse(result["attempted"])
        runner.assert_not_called()


if __name__ == "__main__":
    unittest.main()
