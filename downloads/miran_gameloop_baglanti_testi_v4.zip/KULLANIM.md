# MİRAN Gameloop bağlantı ve derleme testi v4

Bu paket tanılama aracıdır. ESP oyuncu okuma, mesafe ve engel kontrolü henüz
uygulanmadı. Ölçülen paket bilgilerini ve erişilebilen UE4 dosya başlığını raporlar.

## Çalıştırma

1. ZIP'i tamamen yeni bir klasöre çıkar.
2. Python 3.10+ ve Tcl/Tk kurulu olmalıdır; ek Python paketi gerekmez.
3. GameLoop ve PUBG ana menüsü açıkken `BASLAT_GAMELOOP_TEST.bat` dosyasını çalıştır.
4. **Testi başlat** düğmesine bas. Eğitim sahasına girmen gerekmiyor.
5. **Raporu kaydet** ile JSON dosyasını sakla ve inceleme için paylaş.

ADB bağlantısı yoksa **ADB'yi bağla + test** düğmesi, belirtilen tek yerel porta
bağlanmayı dener. Varsayılan port 5555'tir; başarılı bağlantı cihaz listesinden
doğrulanır. Normal **Testi başlat** düğmesi bağlantı açmaz. Otomatik seçim önce
GameLoop kurulumundaki ADB'yi, ardından PATH'teki ADB'yi değerlendirir.
**Kurulu ADB seç** ile dosyayı elle seçebilirsin.

## V4 değişikliği

Eski ADB istemcilerinde doğrudan dosya aktarımı desteklenmeyebilir. Ayrıca
uzaktaki komutun açıklama çıktısı ikili veriye karışabilir. V4, bu durumlar için
sınırlı bir metin aktarımı ekler; metin doğrulandıktan sonra baytlara çevrilir.
İzin reddi, bulunamayan dosya, desteklenmeyen komut, zaman aşımı ve geçersiz
veri ayrı hata kodlarıyla raporlanır. Önceki genel hata mesajından tek başına
izin sorunu olduğu sonucu çıkarılamaz.

Bu uyumluluk yöntemi her Android kurulumunda mevcut olmayabilir. Kullanılabilen
komutlar ve normal dosya izinleri yeterli değilse uygulama bunu raporlar.

## Gönderilen offsetler ve kaynak

`ADAY_OFFSETLER.json`, gönderilen 25 adresi doğrulanmamış aday olarak saklar.
Tanılama uygulaması bu dosyayı kullanarak oyun belleği okumaz veya değiştirmez.
`OFFSET_INCELEMESI.md`, kaynak koduyla karşılaştırmanın sonucunu açıklar.

## Ölçümleri yorumlama

- Windows süreç mimarisi ile Android oyun paketinin ABI'si ayrı bilgilerdir.
  `aow_exe.exe` x64 iken oyun paketi `armeabi-v7a` (ARMv7/32 bit) olabilir.
- Paket `version_name` alanı Android paket yöneticisinden gelir; oyun içi kaynak
  veya hotfix etiketi farklı olabilir.
- `mapped_library: true`, çalışan oyun sürecinin listesinde UE4 eşlemesi
  bulunduğunu gösterir. Bu alan tek başına ELF başlığının okunduğunu söylemez.
- `engine_library.status: available` olduğunda ELF bit sınıfı, makine türü ve
  varsa GNU Build ID okunmuştur. `metadata_source: mapped` eşleme listesindeki
  dosya yolunu, `native_library_dir` paket dizinindeki dosyayı belirtir.
- `read_attempts`, dosya adaylarının sonuçlarını ve hata kodlarını içerir.
  `shell_hex` eski ADB için metin aktarımı, `exec_out` doğrudan aktarım yöntemidir.
- GNU Build ID, tek başına oyuncu adreslerini veya ESP uyumluluğunu sağlamaz.

## Okuma sınırları ve rapor

Araç dosyaya veya oyun belleğine yazmaz; root istemez. Yalnızca mevcut yerel
emülatör bağlantısı üzerinden paket bilgisi, modül listesi ve sınırlı ELF dosya
aralıklarını okur. Telefonlar ve uzak ağ adresleri sorgulanmaz.

ELF ayrıştırıcısı aday başına 256 KiB, çağrı başına 64 KiB ve 512 MiB dosya
aralığı sınırları uygular. Doğrudan aktarımda 4 KiB blok hizalaması nedeniyle
okunan bayt sayısı biraz daha büyük olabilir. Uyumluluk denemesi aynı sınırlı
aralığı yeniden okuyabilir. Tam kütüphane kopyalanmaz veya çalıştırılmaz.
Silinmiş eşlemeler ve APK içinden doğrudan eşlenen kütüphaneler açılmaz.

Rapor tam dosya yolu, cihaz seri numarası veya hesap bilgisi içermez. UE4
eşlemelerinde modül adı, adresler, dosya offset'i, izinler ve silinmiş olma
durumu bulunur. Uygulama raporu otomatik olarak yüklemez.

## Doğrulama

```powershell
py -m unittest -v test_native_metadata test_live_app test_engine_metadata test_engine_integration test_local_connection test_connection_integration test_library_transport
py miran_gameloop_tani.py --check
```

76 otomatik test Linux'ta geçti. Tkinter arayüzü sanal ekranda gerçek
pencerede; Windows ve ADB sonuçları taklit edilerek kontrol edilir. Bu ortamda
gerçek Windows/GameLoop üzerinde canlı test yapılamaz.
