"""Bounded UE4 metadata tests; no process, ADB, network, or library execution."""
import json
import unittest
import miran_gameloop_tani as ep


def make_elf(bits=64, endian="little", machine=None, notes=()):
    header_size = 52 if bits == 32 else 64
    entry_size = 32 if bits == 32 else 56
    header = bytearray(header_size)
    header[:7] = b"\x7fELF" + bytes((1 if bits == 32 else 2, 1 if endian == "little" else 2, 1))
    def put(buffer, offset, value, length):
        buffer[offset:offset + length] = value.to_bytes(length, endian)
    put(header, 16, 3, 2)
    put(header, 18, machine if machine is not None else (40 if bits == 32 else 183), 2)
    put(header, 20, 1, 4)
    if bits == 32:
        put(header, 28, header_size if notes else 0, 4)
        put(header, 40, header_size, 2)
        put(header, 42, entry_size if notes else 0, 2)
        put(header, 44, len(notes), 2)
    else:
        put(header, 32, header_size if notes else 0, 8)
        put(header, 52, header_size, 2)
        put(header, 54, entry_size if notes else 0, 2)
        put(header, 56, len(notes), 2)
    table = bytearray(entry_size * len(notes))
    offset = header_size + len(table)
    for index, note in enumerate(notes):
        entry = index * entry_size
        put(table, entry, 4, 4)
        put(table, entry + (4 if bits == 32 else 8), offset, 4 if bits == 32 else 8)
        put(table, entry + (16 if bits == 32 else 32), len(note), 4 if bits == 32 else 8)
        offset += len(note)
    return header + table + b"".join(notes)


def note(name=b"GNU\0", descriptor=b"\x01\x23\x45\x67", kind=3, endian="little"):
    return (len(name).to_bytes(4, endian) + len(descriptor).to_bytes(4, endian)
            + kind.to_bytes(4, endian) + name + bytes((-len(name)) % 4)
            + descriptor + bytes((-len(descriptor)) % 4))


def read_fixture(blob, requests=None):
    def read(offset, size):
        if requests is not None:
            requests.append((offset, size))
        return blob[offset:offset + size]
    return read


class MapsTests(unittest.TestCase):
    def test_maps_preserve_offsets_but_not_private_paths_in_reports(self):
        text = "1000-2000 r-xp 00001000 00:05 123 /data/app/PRIVATE-user/lib/arm/libUE4.so\n"
        rows = ep.parse_ue4_maps(text)
        self.assertEqual(len(rows), 1)
        self.assertEqual((rows[0].start, rows[0].end, rows[0].offset), (0x1000, 0x2000, 0x1000))
        report = rows[0].to_report()
        self.assertEqual(report["offset"], "0x1000")
        self.assertEqual(report["basename"], "libUE4.so")
        self.assertNotIn("PRIVATE", json.dumps(report))
        self.assertNotIn("PRIVATE", repr(rows[0]))
        self.assertIsNotNone(rows[0].path)

    def test_deleted_rows_are_marked_and_excluded_as_read_candidates(self):
        rows = ep.parse_ue4_maps("1000-2000 r-xp 0 00:05 1 /data/libUE4.so (deleted)")
        self.assertTrue(rows[0].deleted)
        self.assertEqual(ep.engine_library_candidates(None, rows), [])

    def test_exact_basename_and_valid_mapping_fields_required(self):
        text = "\n".join([
            "1000-2000 r-xp 0 00:05 1 /data/libUE4.so.bak",
            "1000-2000 r-xp 0 00:05 1 /data/libOther.so",
            "2000-1000 r-xp 0 00:05 1 /data/libUE4.so",
            "1000-2000 xxxx 0 00:05 1 /data/libUE4.so",
            "1000-2000 r-xp xyz 00:05 1 /data/libUE4.so",
            "1000-2000 r-xp 0 device 1 /data/libUE4.so",
            "1000-2000 r-xp 0 00:05 invalid /data/libUE4.so",
            "FFFFFFFFFFFFFFFFF-FFFFFFFFFFFFFFFFFF r-xp 0 00:05 1 /data/libUE4.so",
        ])
        self.assertEqual(ep.parse_ue4_maps(text), [])

    def test_apk_mapping_can_be_reported_without_unsafe_path_candidate(self):
        rows = ep.parse_ue4_maps("1000-2000 r-xp 0 00:05 1 /data/base.apk!/lib/arm/libUE4.so")
        self.assertEqual(rows[0].basename, "libUE4.so")
        self.assertIsNone(rows[0].path)
        self.assertEqual(ep.engine_library_candidates(None, rows), [])

    def test_mapping_output_and_text_are_bounded(self):
        rows = ep.parse_ue4_maps("1000-2000 r-xp 0 00:05 1 /data/libUE4.so\n" * 129)
        self.assertEqual(len(rows), 128)
        for text in ("x" * (ep.ENGINE_MAP_TEXT_LIMIT + 1), "ğ" * (ep.ENGINE_MAP_TEXT_LIMIT // 2 + 1)):
            with self.subTest(size=len(text)), self.assertRaises(ep.EngineProbeError):
                ep.parse_ue4_maps(text)

    def test_candidate_order_deduplication_and_native_fallback(self):
        mapped = ep.MapRow(1, 2, 0, "r-xp", path="/mapped/libUE4.so")
        result = ep.engine_library_candidates("/native/arm/", [mapped, mapped])
        self.assertEqual(result, [("/mapped/libUE4.so", "mapped"), ("/native/arm/libUE4.so", "native_library_dir")])
        self.assertEqual(ep.engine_library_candidates("/mapped", [mapped]), [("/mapped/libUE4.so", "mapped")])

    def test_candidate_limit_and_unsafe_path_rejection(self):
        rows = [ep.MapRow(1, 2, 0, "r-xp", path=f"/mapped/{index}/libUE4.so") for index in range(8)]
        self.assertEqual(len(ep.engine_library_candidates("/native", rows)), 4)
        for directory in ("relative", "/bad/../arm", "/bad/./arm", "/bad//arm", "/bad;$HOME", "/bad\narm", "/bad!arm"):
            with self.subTest(directory=directory):
                self.assertEqual(ep.engine_library_candidates(directory, []), [])


class ElfTests(unittest.TestCase):
    def test_minimal_elf32_is_read_without_requesting_64_bytes(self):
        blob = make_elf(bits=32)
        self.assertEqual(len(blob), 52)
        calls = []
        metadata = ep.metadata_from_reader(read_fixture(blob, calls))
        self.assertEqual(metadata, {"elf_bits": 32, "machine": "ARM", "gnu_build_id": None, "build_version_verified": False})
        self.assertEqual(calls, [(0, 16), (16, 36)])

    def test_supported_classes_machines_and_endianness(self):
        for bits, machine, name in ((32, 40, "ARM"), (32, 3, "x86"), (64, 183, "AArch64"), (64, 62, "x86_64")):
            for endian in ("little", "big"):
                with self.subTest(bits=bits, machine=machine, endian=endian):
                    metadata = ep.metadata_from_reader(read_fixture(make_elf(bits=bits, machine=machine, endian=endian)))
                    self.assertEqual((metadata["elf_bits"], metadata["machine"]), (bits, name))

    def test_gnu_build_id_scans_note_segments_and_obeys_endian(self):
        for bits in (32, 64):
            for endian in ("little", "big"):
                blob = make_elf(bits=bits, endian=endian, notes=[note(name=b"OTHER\0", kind=1, endian=endian), note(descriptor=b"\xde\xad\xbe\xef", endian=endian)])
                with self.subTest(bits=bits, endian=endian):
                    metadata = ep.metadata_from_reader(read_fixture(blob))
                    self.assertEqual(metadata["gnu_build_id"], "deadbeef")
                    self.assertFalse(metadata["build_version_verified"])

    def test_truncated_range_and_read_errors_are_clear_and_redacted(self):
        with self.assertRaisesRegex(ep.EngineProbeError, "eksik"):
            ep.metadata_from_reader(read_fixture(make_elf()[:40]))
        def denied(offset, size):
            raise PermissionError("/data/PRIVATE-account/libUE4.so denied")
        with self.assertRaises(ep.EngineProbeError) as captured:
            ep.metadata_from_reader(denied)
        self.assertNotIn("PRIVATE", str(captured.exception))

    def test_invalid_identity_header_version_and_machine_rejected(self):
        mutations = [(0, b"X"), (4, b"\x03"), (5, b"\x03"), (6, b"\x00"),
                     (18, (40).to_bytes(2, "little")), (20, b"\x00\x00\x00\x00"), (52, b"\x00\x00")]
        for offset, value in mutations:
            blob = make_elf()
            blob[offset:offset + len(value)] = value
            with self.subTest(offset=offset), self.assertRaises(ep.EngineProbeError):
                ep.metadata_from_reader(read_fixture(blob))

    def test_program_count_entry_size_and_huge_offsets_rejected_before_read(self):
        for offset, value in ((56, (257).to_bytes(2, "little")), (54, (257).to_bytes(2, "little")),
                              (32, (ep.ENGINE_MAX_OFFSET + 1).to_bytes(8, "little"))):
            blob = make_elf(notes=[note()])
            blob[offset:offset + len(value)] = value
            calls = []
            with self.subTest(offset=offset), self.assertRaises(ep.EngineProbeError):
                ep.metadata_from_reader(read_fixture(blob, calls))
            self.assertEqual(len(calls), 2)

    def test_oversize_note_rejected_without_fetching_note(self):
        blob = make_elf(notes=[note()])
        blob[64 + 32:64 + 40] = (ep.ENGINE_MAX_READ + 1).to_bytes(8, "little")
        calls = []
        with self.assertRaisesRegex(ep.EngineProbeError, "64 KiB"):
            ep.metadata_from_reader(read_fixture(blob, calls))
        self.assertEqual(len(calls), 3)

    def test_huge_note_offset_rejected_before_request(self):
        blob = make_elf(notes=[note()])
        blob[64 + 8:64 + 16] = (2**64 - 1).to_bytes(8, "little")
        calls = []
        with self.assertRaisesRegex(ep.EngineProbeError, "512 MiB"):
            ep.metadata_from_reader(read_fixture(blob, calls))
        self.assertEqual(len(calls), 3)

    def test_total_read_budget_and_per_call_cap_are_enforced(self):
        blob = make_elf(notes=[bytes(ep.ENGINE_MAX_READ)] * 5)
        calls = []
        with self.assertRaisesRegex(ep.EngineProbeError, "256 KiB"):
            ep.metadata_from_reader(read_fixture(blob, calls))
        self.assertLessEqual(sum(size for _, size in calls), ep.ENGINE_TOTAL_READ_LIMIT)
        self.assertLessEqual(max(size for _, size in calls), ep.ENGINE_MAX_READ)
        self.assertEqual(sum(size == ep.ENGINE_MAX_READ for _, size in calls), 3)

    def test_malformed_note_descriptor_does_not_escape_bounds(self):
        damaged = bytearray(note())
        damaged[4:8] = (2**32 - 1).to_bytes(4, "little")
        with self.assertRaisesRegex(ep.EngineProbeError, "not verisi"):
            ep.metadata_from_reader(read_fixture(make_elf(notes=[damaged])))


if __name__ == "__main__":
    unittest.main()
