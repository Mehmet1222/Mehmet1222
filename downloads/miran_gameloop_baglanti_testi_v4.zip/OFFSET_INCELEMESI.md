# Offset ve kaynak incelemesi

Gönderilen `namespace Offset` değerleri, daha önce incelenen
[VietHungDev07/Pubg-Mobile-External-ESP](https://github.com/VietHungDev07/Pubg-Mobile-External-ESP)
kaynağındaki `offset.hpp` ile eşleşiyor. Gönderilen README aynı proje başlığını
ve özellik iddialarını içeriyor. `.gitignore` derleme ürünlerini dışlayan bir
Git yapılandırması; çalışan uygulama veya ek kaynak kod içermiyor.

İncelenen `Source.cpp` içindeki başlangıç akışı, `PointerUe4` sabitinden okuma
yapıp `Gnames` ve `Gword` sabitlerini kullanıyor. Offset yorumlarındaki imza
metinleri çalışan tarayıcı kodu değildir. README'deki otomatik güncelleme
iddiası, bu kod akışının PUBG 4.6 sürümünde uyumlu olduğunu kanıtlamaz.

`DWORD` tabanlı okuma ve `EntityCount = EntityList + 4` düzeni 32 bit adres
yerleşimini varsayıyor. Windows uygulamasını x64 derlemek, bu hedef yerleşimi
kendiliğinden 64 bite dönüştürmez. İmza yorumları x86 makine komutu dizilerine
benziyor; bunların ARMv7 ELF üzerinde veya GameLoop'un çevrilmiş kodunda nerede
aranacağı ve sonuçtan adresin nasıl çıkarılacağı ayrıca doğrulanmalıdır.

`never change` yorumları alanların bütün sürümlerde sabit kalacağını garanti
etmez. Paket sürümü ve gerçek ELF kimliği doğrulanmadan bu değerler uygun
offsetler olarak kabul edilemez. Eşleme listesinde bir adresin yer alması da
o adreste beklenen oyuncu/kamera nesnesinin bulunduğunu tek başına kanıtlamaz.

Bu listede engel testi veya doğrulanmış görünürlük alanı yok. Takım rengi,
sağlık, ekranda görünme ya da son çizim zamanı, hedefle kamera arasında duvar
bulunup bulunmadığının doğrudan ölçümü değildir. İstenen kırmızı/yeşil ESP
için oyuncu/kamera konumları, ekran dönüşümü, 200 metre sınırı ve gerçek engel
sonucu birlikte uygulanıp canlı ortamda doğrulanmalıdır.

Paketteki `ADAY_OFFSETLER.json` yalnızca inceleme kaydıdır. V4 tanılama aracında
oyuncu verisi sağlayıcısı veya çalışan ESP uygulanmış değildir.
