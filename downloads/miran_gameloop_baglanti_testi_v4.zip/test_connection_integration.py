import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
import miran_gameloop_tani as app


class ConnectionIntegrationTests(unittest.TestCase):
    def test_offline_transport_is_reported_without_package_queries(self):
        def runner(exe, args, timeout=12):
            if args == ["devices"]:
                return "127.0.0.1:5555 offline\nUSBPHONE device\n"
            if args == ["version"]:
                return "Android Debug Bridge version 1.0.41\nVersion 36.0.0-123\nInstalled as C:/Users/PRIVATE/adb.exe"
            self.fail(f"Unexpected command: {args[0]}")
        report = app.probe_adb("adb.exe", runner)
        self.assertEqual(report["status"], "offline")
        self.assertEqual(report["local_device_count"], 0)
        self.assertEqual(report["local_transport_states"]["offline"], 1)
        self.assertEqual(report["client_version"]["protocol_version"], "1.0.41")
        self.assertNotIn("PRIVATE", json.dumps(report))
        self.assertNotIn("USBPHONE", json.dumps(report))

    def test_unauthorized_and_conflicting_states_never_query_package(self):
        for response, status in [("localhost:5555 unauthorized", "unauthorized"),
                                 ("127.0.0.1:5555 device\n127.0.0.1:5555 offline", "offline")]:
            calls = []
            def runner(exe, args, timeout=12):
                calls.append(args)
                return response if args == ["devices"] else "Android Debug Bridge version 1.0.41"
            result = app.probe_adb("adb.exe", runner)
            self.assertEqual(result["status"], status)
            self.assertEqual(calls, [["devices"], ["version"]])
            self.assertFalse(result["packages"])

    def test_installed_gameloop_adb_precedes_path_adb(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            game = base / "GameLoop"
            other = base / "SDK"
            game.mkdir()
            other.mkdir()
            neighbor = game / "adb.exe"
            path_adb = other / "adb.exe"
            neighbor.write_bytes(b"not executed")
            path_adb.write_bytes(b"not executed")
            process = app.ProcessInfo(1, "aow_exe.exe", path=str(game / "aow_exe.exe"))
            with patch.object(app.shutil, "which", return_value=str(path_adb)):
                candidates = app.find_adb_candidates([process])
            self.assertEqual(candidates[0], str(neighbor.resolve()))
            self.assertIn(str(path_adb.resolve()), candidates)

    def test_invalid_explicit_selection_does_not_silently_fallback(self):
        with tempfile.TemporaryDirectory() as directory:
            path_adb = Path(directory) / "adb.exe"
            path_adb.write_bytes(b"not executed")
            with patch.object(app.shutil, "which", return_value=str(path_adb)):
                self.assertEqual(app.find_adb_candidates([], str(Path(directory) / "missing.exe")), [])

    def test_normal_report_does_not_connect_automatically(self):
        native = {"supported": True, "processes": [app.ProcessInfo(1, "aow_exe.exe")], "errors": []}
        adb = {"status": "unavailable", "local_device_count": 0, "packages": [], "errors": []}
        with patch.object(app, "probe_gameloop_processes", return_value=native), \
             patch.object(app, "find_adb_candidates", return_value=["adb.exe"]), \
             patch.object(app, "probe_adb", return_value=adb), \
             patch.object(app, "reconnect_local_adb") as reconnect:
            report = app.collect_report()
        reconnect.assert_not_called()
        self.assertNotIn("reconnection", report["adb"])

    def test_explicit_reconnect_has_dedicated_status_then_real_probe(self):
        native = {"supported": True, "processes": [app.ProcessInfo(1, "aow_exe.exe")], "errors": []}
        adb = {"status": "offline", "local_device_count": 0, "packages": [], "errors": []}
        action = {"attempted": True, "port": 5555, "status": "offline", "message": "Çevrimdışı"}
        with patch.object(app, "probe_gameloop_processes", return_value=native), \
             patch.object(app, "find_adb_candidates", return_value=["adb.exe"]), \
             patch.object(app, "probe_adb", return_value=adb) as probe, \
             patch.object(app, "reconnect_local_adb", return_value=action) as reconnect:
            report = app.collect_report(reconnect_port=5555)
        reconnect.assert_called_once_with("adb.exe", 5555, app.adb_command)
        probe.assert_called_once_with("adb.exe")
        self.assertEqual(report["adb"]["reconnection"]["status"], "offline")
        self.assertEqual(report["adb"]["status"], "offline")
        self.assertFalse(report["esp"]["implemented"])


if __name__ == "__main__":
    unittest.main()
